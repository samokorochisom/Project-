import { DarkTheme, DefaultTheme, ThemeProvider as NavigationThemeProvider } from '@react-navigation/native';
import { Stack } from 'expo-router';
import * as SplashScreen from 'expo-splash-screen';
import { StatusBar } from 'expo-status-bar';
import { useEffect, useState, useMemo } from 'react';
import 'react-native-reanimated';
import { useRouter, useSegments } from 'expo-router';
import { useColorScheme } from '@/hooks/useColorScheme';
import { hasProfile } from '@/utils/profileStorage';
import { ThemeProvider, useTheme as useCustomTheme } from '@/contexts/ThemeContext';

SplashScreen.preventAutoHideAsync();

function NavigationWrapper({ children }: { children: React.ReactNode }) {
  const { currentTheme } = useCustomTheme();
  const colorScheme = useColorScheme();

  const customNavigationTheme = useMemo(() => ({
    ...(colorScheme === 'dark' ? DarkTheme : DefaultTheme),
    colors: {
      ...(colorScheme === 'dark' ? DarkTheme.colors : DefaultTheme.colors),
      primary: currentTheme.primary,
      background: currentTheme.background,
      card: currentTheme.cardBackground,
      text: currentTheme.textPrimary,
      border: currentTheme.border,
      notification: currentTheme.accent,
    },
  }), [currentTheme, colorScheme]);

  return <NavigationThemeProvider value={customNavigationTheme}>{children}</NavigationThemeProvider>;
}

function RootNavigator() {
  const [isReady, setIsReady] = useState(false);
  const [hasUserProfile, setHasUserProfile] = useState(false);
  const segments = useSegments();
  const router = useRouter();

  useEffect(() => {
    async function prepare() {
      try {
        const profileExists = await hasProfile();
        setHasUserProfile(profileExists);
      } catch (e) {
        console.warn(e);
      } finally {
        setIsReady(true);
      }
    }
    prepare();
  }, []);

  useEffect(() => {
    if (!isReady) return;

    const firstSegment = segments[0] || '';
    const inAuthGroup = firstSegment === '(tabs)';
    const allowedRoutes = ['add-notes', 'course-notes', 'note-reader', 'document-reader', 'mood-selection', 'study'];
    const inAllowedRoutes = allowedRoutes.includes(firstSegment);

    if (!hasUserProfile && inAuthGroup) {
      router.replace('/profile-setup');
    } else if (hasUserProfile && !inAuthGroup && !inAllowedRoutes && firstSegment !== 'profile-setup') {
      router.replace('/(tabs)');
    }
  }, [hasUserProfile, segments, isReady]);

  useEffect(() => {
    if (isReady) SplashScreen.hideAsync();
  }, [isReady]);

  if (!isReady) return null;

  return (
    <NavigationWrapper>
      <Stack>
        <Stack.Screen name="profile-setup" options={{ headerShown: false }} />
        <Stack.Screen name="(tabs)" options={{ headerShown: false }} />
        <Stack.Screen name="course-notes" options={{ headerShown: false }} />
        <Stack.Screen name="add-notes" options={{ headerShown: false }} />
        <Stack.Screen name="note-reader" options={{ headerShown: false }} />
        <Stack.Screen name="document-reader" options={{ headerShown: false }} />
        <Stack.Screen name="mood-selection" options={{ headerShown: false }} />
        <Stack.Screen name="study" options={{ headerShown: false }} />
        <Stack.Screen name="+not-found" />
      </Stack>
      <StatusBar style="auto" />
    </NavigationWrapper>
  );
}

export default function RootLayout() {
  return (
    <ThemeProvider>
      <RootNavigator />
    </ThemeProvider>
  );
}