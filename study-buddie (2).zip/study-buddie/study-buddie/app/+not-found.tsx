import { Link, Stack } from 'expo-router';
import { StyleSheet, View, Text } from 'react-native';

export default function NotFoundScreen() {
 return (
   <>
     <Stack.Screen options={{ title: 'Oops!' }} />
     <View style={styles.container}>
       <Text style={styles.emoji}>🤔</Text>
       <Text style={styles.title}>Page Not Found</Text>
       <Text style={styles.subtitle}>
         This screen doesn't exist.
       </Text>
       <Link href="/" style={styles.link}>
         <Text style={styles.linkText}>Go to home screen</Text>
       </Link>
     </View>
   </>
 );
}

const styles = StyleSheet.create({
 container: {
   flex: 1,
   alignItems: 'center',
   justifyContent: 'center',
   padding: 20,
   backgroundColor: '#F5F3ED', // Soft warm gray-beige
 },
 emoji: {
   fontSize: 80,
   marginBottom: 16,
 },
 title: {
   fontSize: 32,
   fontWeight: 'bold',
   color: '#3D4037', // Deep forest green-brown
   marginBottom: 8,
 },
 subtitle: {
   fontSize: 18,
   color: '#6B7064', // Muted olive
   marginBottom: 32,
   textAlign: 'center',
 },
 link: {
   backgroundColor: '#8B9D83', // Soft olive green
   paddingHorizontal: 32,
   paddingVertical: 16,
   borderRadius: 12,
   shadowColor: '#6B7064',
   shadowOffset: {
     width: 0,
     height: 4,
   },
   shadowOpacity: 0.3,
   shadowRadius: 8,
   elevation: 4,
 },
 linkText: {
   fontSize: 18,
   fontWeight: '600',
   color: '#FDFBF7', // Off-white
 },
});