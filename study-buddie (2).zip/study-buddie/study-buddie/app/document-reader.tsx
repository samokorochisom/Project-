import React, { useState, useEffect } from 'react';
import {
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
  SafeAreaView,
  ScrollView,
  Alert,
  Platform,
} from 'react-native';
import { useRouter, useLocalSearchParams } from 'expo-router';
import * as Haptics from 'expo-haptics';
import * as DocumentPicker from 'expo-document-picker';
import { Note, Document as DocType } from '@/types/note';
import {
  getNotesByCourse,
  getDocumentsByCourse,
  deleteNote,
  deleteDocument,
  addDocument,
} from '@/utils/notesStorage';
import { useFocusEffect } from '@react-navigation/native';
import { useCallback } from 'react';
import { useTheme } from '@/contexts/ThemeContext';
import { FONTS } from '@/constants/Themes';

type TabType = 'notes' | 'documents';

export default function CourseNotesScreen() {
  const router = useRouter();
  const { currentTheme, settings } = useTheme();
  const params = useLocalSearchParams();
  const courseId = params.courseId as string;
  const courseName = params.courseName as string;
  const courseColor = params.courseColor as string;

  const [activeTab, setActiveTab] = useState<TabType>('notes');
  const [notes, setNotes] = useState<Note[]>([]);
  const [documents, setDocuments] = useState<DocType[]>([]);

  useFocusEffect(
    useCallback(() => {
      loadData();
    }, [])
  );

  useEffect(() => {
    loadData();
  }, [activeTab]);

  const loadData = async () => {
    try {
      const [notesData, documentsData] = await Promise.all([
        getNotesByCourse(courseId),
        getDocumentsByCourse(courseId),
      ]);

      setNotes(notesData);
      setDocuments(documentsData);
    } catch (error) {
      console.error('Error loading data:', error);
    }
  };

  const handleAddNote = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    router.push({
      pathname: '/add-notes',
      params: {
        courseId,
        courseName,
      }
    });
  };

  const handlePickDocument = async () => {
    try {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
      
      const result = await DocumentPicker.getDocumentAsync({
        type: '*/*',
        copyToCacheDirectory: true,
      });

      if (!result.canceled && result.assets && result.assets[0]) {
        const file = result.assets[0];
        
        const newDocument: DocType = {
          id: Date.now().toString(),
          courseId,
          courseName,
          name: file.name,
          uri: file.uri,
          type: file.mimeType || 'unknown',
          size: file.size || 0,
          uploadedAt: Date.now(),
        };

        await addDocument(newDocument);
        await loadData();
        Alert.alert('Success', 'Document uploaded successfully!');
      }
    } catch (error) {
      console.error('Error picking document:', error);
      Alert.alert('Error', 'Failed to upload document');
    }
  };

  const handleDocumentPress = (doc: DocType) => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    router.push({
      pathname: '/document-reader',
      params: {
        name: doc.name,
        uri: doc.uri,
        type: doc.type,
      }
    });
  };

  const handleNotePress = (note: Note) => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    router.push({
      pathname: '/note-reader',
      params: {
        noteId: note.id,
        courseId,
        courseName,
        title: note.title,
        content: note.content,
        tags: note.tags?.join(',') || '',
        date: formatDate(note.updatedAt),
      }
    });
  };

  const handleDeleteNote = (noteId: string, noteTitle: string) => {
    Alert.alert(
      'Delete Note',
      `Are you sure you want to delete "${noteTitle}"?`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: async () => {
            try {
              await deleteNote(noteId);
              await loadData();
              Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
            } catch (error) {
              Alert.alert('Error', 'Failed to delete note');
            }
          },
        },
      ]
    );
  };

  const handleDeleteDocument = (docId: string, docName: string) => {
    Alert.alert(
      'Delete Document',
      `Are you sure you want to delete "${docName}"?`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: async () => {
            try {
              await deleteDocument(docId);
              await loadData();
              Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
            } catch (error) {
              Alert.alert('Error', 'Failed to delete document');
            }
          },
        },
      ]
    );
  };

  const formatDate = (timestamp: number) => {
    const date = new Date(timestamp);
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    return `${months[date.getMonth()]} ${date.getDate()}, ${date.getFullYear()}`;
  };

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
  };

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: currentTheme.background }]}>
      <ScrollView 
        style={styles.scrollView}
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        {/* Header */}
        <View style={styles.header}>
          <TouchableOpacity 
            style={styles.backButton}
            onPress={() => router.back()}
            activeOpacity={0.7}
          >
            <Text style={[
              styles.backButtonText, 
              { 
                color: currentTheme.primary,
                fontFamily: FONTS[settings.fontStyle].bold
              }
            ]}>
              ← Back
            </Text>
          </TouchableOpacity>
          <View style={[styles.courseHeader, { backgroundColor: courseColor + '40' }]}>
            <Text style={[
              styles.courseName, 
              { 
                color: currentTheme.textPrimary,
                fontFamily: FONTS[settings.fontStyle].bold
              }
            ]}>
              {courseName}
            </Text>
          </View>
        </View>

        {/* Tabs */}
        <View style={styles.tabs}>
          <TouchableOpacity
            style={[
              styles.tab,
              { backgroundColor: currentTheme.cardBackground },
              activeTab === 'notes' && { backgroundColor: currentTheme.primary }
            ]}
            onPress={() => setActiveTab('notes')}
          >
            <Text style={[
              styles.tabText,
              { 
                color: currentTheme.textSecondary,
                fontFamily: FONTS[settings.fontStyle].bold
              },
              activeTab === 'notes' && { color: currentTheme.cardBackground }
            ]}>
              Notes ({notes.length})
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[
              styles.tab,
              { backgroundColor: currentTheme.cardBackground },
              activeTab === 'documents' && { backgroundColor: currentTheme.primary }
            ]}
            onPress={() => setActiveTab('documents')}
          >
            <Text style={[
              styles.tabText,
              { 
                color: currentTheme.textSecondary,
                fontFamily: FONTS[settings.fontStyle].bold
              },
              activeTab === 'documents' && { color: currentTheme.cardBackground }
            ]}>
              Files ({documents.length})
            </Text>
          </TouchableOpacity>
        </View>

        {/* Content */}
        <View style={styles.content}>
          {activeTab === 'notes' && (
            <>
              {notes.length === 0 ? (
                <View style={[styles.emptyState, { backgroundColor: currentTheme.cardBackground }]}>
                  <Text style={styles.emptyEmoji}>📝</Text>
                  <Text style={[
                    styles.emptyText, 
                    { 
                      color: currentTheme.textPrimary,
                      fontFamily: FONTS[settings.fontStyle].bold
                    }
                  ]}>
                    No notes yet
                  </Text>
                  <Text style={[
                    styles.emptySubtext, 
                    { 
                      color: currentTheme.textSecondary,
                      fontFamily: FONTS[settings.fontStyle].regular
                    }
                  ]}>
                    Start taking notes for this course!
                  </Text>
                </View>
              ) : (
                notes.map((note) => (
                  <TouchableOpacity
                    key={note.id}
                    style={[styles.itemCard, { backgroundColor: currentTheme.cardBackground }]}
                    onPress={() => handleNotePress(note)}
                    onLongPress={() => handleDeleteNote(note.id, note.title)}
                    activeOpacity={0.7}
                  >
                    <View style={styles.itemHeader}>
                      <Text style={[
                        styles.itemTitle, 
                        { 
                          color: currentTheme.textPrimary,
                          fontFamily: FONTS[settings.fontStyle].bold
                        }
                      ]}>
                        {note.title}
                      </Text>
                      <Text style={[
                        styles.itemDate, 
                        { 
                          color: currentTheme.textTertiary,
                          fontFamily: FONTS[settings.fontStyle].regular
                        }
                      ]}>
                        {formatDate(note.updatedAt)}
                      </Text>
                    </View>
                    <Text 
                      style={[
                        styles.itemContent, 
                        { 
                          color: currentTheme.textSecondary,
                          fontFamily: FONTS[settings.fontStyle].regular
                        }
                      ]} 
                      numberOfLines={2}
                    >
                      {note.content}
                    </Text>
                    {note.tags && note.tags.length > 0 && (
                      <View style={styles.tagsContainer}>
                        {note.tags.map((tag, index) => (
                          <View key={index} style={[styles.tag, { backgroundColor: currentTheme.accent }]}>
                            <Text style={[
                              styles.tagText, 
                              { 
                                color: currentTheme.textSecondary,
                                fontFamily: FONTS[settings.fontStyle].regular
                              }
                            ]}>
                              #{tag}
                            </Text>
                          </View>
                        ))}
                      </View>
                    )}
                  </TouchableOpacity>
                ))
              )}
            </>
          )}

          {activeTab === 'documents' && (
            <>
              {documents.length === 0 ? (
                <View style={[styles.emptyState, { backgroundColor: currentTheme.cardBackground }]}>
                  <Text style={styles.emptyEmoji}>📄</Text>
                  <Text style={[
                    styles.emptyText, 
                    { 
                      color: currentTheme.textPrimary,
                      fontFamily: FONTS[settings.fontStyle].bold
                    }
                  ]}>
                    No documents uploaded
                  </Text>
                  <Text style={[
                    styles.emptySubtext, 
                    { 
                      color: currentTheme.textSecondary,
                      fontFamily: FONTS[settings.fontStyle].regular
                    }
                  ]}>
                    Upload PDFs, images, and other files!
                  </Text>
                </View>
              ) : (
                documents.map((doc) => (
                  <TouchableOpacity
                    key={doc.id}
                    style={[styles.itemCard, { backgroundColor: currentTheme.cardBackground }]}
                    onPress={() => handleDocumentPress(doc)}
                    onLongPress={() => handleDeleteDocument(doc.id, doc.name)}
                    activeOpacity={0.7}
                  >
                    <View style={styles.documentRow}>
                      <View style={[styles.documentIcon, { backgroundColor: currentTheme.accent }]}>
                        <Text style={styles.documentEmoji}>
                          {doc.type.includes('pdf') ? '📕' : 
                           doc.type.includes('image') ? '🖼️' : '📄'}
                        </Text>
                      </View>
                      <View style={styles.documentInfo}>
                        <Text 
                          style={[
                            styles.itemTitle, 
                            { 
                              color: currentTheme.textPrimary,
                              fontFamily: FONTS[settings.fontStyle].bold
                            }
                          ]} 
                          numberOfLines={1}
                        >
                          {doc.name}
                        </Text>
                        <Text style={[
                          styles.documentMeta, 
                          { 
                            color: currentTheme.textTertiary,
                            fontFamily: FONTS[settings.fontStyle].regular
                          }
                        ]}>
                          {formatFileSize(doc.size)} • {formatDate(doc.uploadedAt)}
                        </Text>
                      </View>
                      <Text style={[styles.openIcon, { color: currentTheme.textSecondary }]}>📂</Text>
                    </View>
                  </TouchableOpacity>
                ))
              )}
            </>
          )}
        </View>

        {/* Add Button */}
        <TouchableOpacity
          style={[styles.addButton, { backgroundColor: currentTheme.primary }]}
          onPress={
            activeTab === 'notes' ? handleAddNote : handlePickDocument
          }
          activeOpacity={0.8}
        >
          <Text style={[
            styles.addButtonText, 
            { 
              color: currentTheme.cardBackground,
              fontFamily: FONTS[settings.fontStyle].bold
            }
          ]}>
            {activeTab === 'notes' ? '+ Add Note' : '+ Upload Document'}
          </Text>
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    padding: 20,
  },
  header: {
    marginBottom: 24,
  },
  backButton: {
    marginBottom: 12,
  },
  backButtonText: {
    fontSize: 16,
    fontWeight: '600',
  },
  courseHeader: {
    borderRadius: 12,
    padding: 16,
  },
  courseName: {
    fontSize: 24,
    fontWeight: 'bold',
  },
  tabs: {
    flexDirection: 'row',
    gap: 8,
    marginBottom: 24,
  },
  tab: {
    flex: 1,
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderRadius: 12,
    alignItems: 'center',
  },
  tabText: {
    fontSize: 14,
    fontWeight: '600',
  },
  content: {
    gap: 12,
    marginBottom: 24,
  },
  emptyState: {
    borderRadius: 16,
    padding: 40,
    alignItems: 'center',
  },
  emptyEmoji: {
    fontSize: 64,
    marginBottom: 16,
  },
  emptyText: {
    fontSize: 20,
    fontWeight: '600',
    marginBottom: 8,
  },
  emptySubtext: {
    fontSize: 16,
    textAlign: 'center',
  },
  itemCard: {
    borderRadius: 12,
    padding: 16,
    shadowColor: '#6B7064',
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowOpacity: 0.08,
    shadowRadius: 4,
    elevation: 2,
  },
  itemHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  itemTitle: {
    fontSize: 18,
    fontWeight: '700',
    flex: 1,
  },
  itemDate: {
    fontSize: 12,
  },
  itemContent: {
    fontSize: 14,
    lineHeight: 20,
    marginBottom: 8,
  },
  tagsContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
    marginTop: 8,
  },
  tag: {
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 4,
  },
  tagText: {
    fontSize: 12,
    fontWeight: '500',
  },
  documentRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  documentIcon: {
    width: 50,
    height: 50,
    borderRadius: 8,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  documentEmoji: {
    fontSize: 28,
  },
  documentInfo: {
    flex: 1,
  },
  documentMeta: {
    fontSize: 12,
    marginTop: 4,
  },
  openIcon: {
    fontSize: 24,
    marginLeft: 8,
  },
  addButton: {
    borderRadius: 12,
    padding: 18,
    alignItems: 'center',
    shadowColor: '#6B7064',
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 4,
  },
  addButtonText: {
    fontSize: 18,
    fontWeight: '600',
  },
});