import React, { useState, useEffect } from 'react';
import {
 StyleSheet,
 View,
 Text,
 TextInput,
 TouchableOpacity,
 SafeAreaView,
 ScrollView,
 Alert,
} from 'react-native';
import * as Haptics from 'expo-haptics';
import { UserProfile } from '@/types/profile';
import { loadProfile, updateProfile } from '@/utils/profileStorage';
import { THEMES, FONTS } from '@/constants/Themes';
import { useTheme } from '@/contexts/ThemeContext';
 
export default function ProfileScreen() {
 const { settings, currentTheme, updateTheme, updateFont } = useTheme();
 
 const [profile, setProfile] = useState<UserProfile>({
   name: '',
   school: '',
   age: '',
   email: '',
   createdAt: Date.now(),
 });
 const [isEditing, setIsEditing] = useState(false);
 
 useEffect(() => {
   loadData();
 }, []);
 
 const loadData = async () => {
   try {
     const profileData = await loadProfile();
     if (profileData) {
       setProfile(profileData);
     }
   } catch (error) {
     console.error('Error loading data:', error);
   }
 };
 
 const handleSaveProfile = async () => {
   if (!profile.name.trim()) {
     Alert.alert('Error', 'Name is required');
     return;
   }
 
   try {
     Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
     await updateProfile(profile);
     setIsEditing(false);
     Alert.alert('Success', 'Profile updated successfully!');
   } catch (error) {
     Alert.alert('Error', 'Failed to update profile');
   }
 };
 
 const handleThemeChange = async (theme: 'green' | 'pink') => {
   try {
     Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
     await updateTheme(theme);
   } catch (error) {
     Alert.alert('Error', 'Failed to change theme');
   }
 };
 
 const handleFontChange = async (fontStyle: 'default' | 'serif' | 'mono') => {
   try {
     Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
     await updateFont(fontStyle);
   } catch (error) {
     Alert.alert('Error', 'Failed to change font');
   }
 };
 
 return (
   <SafeAreaView style={[styles.container, { backgroundColor: currentTheme.background }]}>
     <ScrollView
       style={styles.scrollView}
       contentContainerStyle={styles.scrollContent}
       showsVerticalScrollIndicator={false}
     >
       <Text style={[
         styles.title, 
         { 
           color: currentTheme.textPrimary,
           fontFamily: FONTS[settings.fontStyle].bold
         }
       ]}>
         Profile
       </Text>
 
       {/* Profile Section */}
       <View style={[styles.section, { backgroundColor: currentTheme.cardBackground }]}>
         <View style={styles.sectionHeader}>
           <Text style={[
             styles.sectionTitle, 
             { 
               color: currentTheme.textPrimary,
               fontFamily: FONTS[settings.fontStyle].bold
             }
           ]}>
             Personal Information
           </Text>
           {!isEditing && (
             <TouchableOpacity
               onPress={() => setIsEditing(true)}
               activeOpacity={0.7}
             >
               <Text style={[
                 styles.editButton, 
                 { 
                   color: currentTheme.primary,
                   fontFamily: FONTS[settings.fontStyle].bold
                 }
               ]}>
                 Edit
               </Text>
             </TouchableOpacity>
           )}
         </View>
 
         <View style={styles.profileInfo}>
           <View style={styles.inputGroup}>
             <Text style={[
               styles.label, 
               { 
                 color: currentTheme.textPrimary,
                 fontFamily: FONTS[settings.fontStyle].bold
               }
             ]}>
               Name *
             </Text>
             <TextInput
               style={[
                 styles.input,
                 { 
                   backgroundColor: currentTheme.background,
                   borderColor: currentTheme.border,
                   color: currentTheme.textPrimary,
                   fontFamily: FONTS[settings.fontStyle].regular
                 }
               ]}
               placeholder="Your name"
               placeholderTextColor={currentTheme.textTertiary}
               value={profile.name}
               onChangeText={(text) => setProfile({ ...profile, name: text })}
               editable={isEditing}
             />
           </View>
 
           <View style={styles.inputGroup}>
             <Text style={[
               styles.label, 
               { 
                 color: currentTheme.textPrimary,
                 fontFamily: FONTS[settings.fontStyle].bold
               }
             ]}>
               School
             </Text>
             <TextInput
               style={[
                 styles.input,
                 { 
                   backgroundColor: currentTheme.background,
                   borderColor: currentTheme.border,
                   color: currentTheme.textPrimary,
                   fontFamily: FONTS[settings.fontStyle].regular
                 }
               ]}
               placeholder="Your school/university"
               placeholderTextColor={currentTheme.textTertiary}
               value={profile.school}
               onChangeText={(text) => setProfile({ ...profile, school: text })}
               editable={isEditing}
             />
           </View>
 
           <View style={styles.inputGroup}>
             <Text style={[
               styles.label, 
               { 
                 color: currentTheme.textPrimary,
                 fontFamily: FONTS[settings.fontStyle].bold
               }
             ]}>
               Age
             </Text>
             <TextInput
               style={[
                 styles.input,
                 { 
                   backgroundColor: currentTheme.background,
                   borderColor: currentTheme.border,
                   color: currentTheme.textPrimary,
                   fontFamily: FONTS[settings.fontStyle].regular
                 }
               ]}
               placeholder="Your age"
               placeholderTextColor={currentTheme.textTertiary}
               value={profile.age}
               onChangeText={(text) => setProfile({ ...profile, age: text })}
               keyboardType="numeric"
               editable={isEditing}
             />
           </View>
 
           <View style={styles.inputGroup}>
             <Text style={[
               styles.label, 
               { 
                 color: currentTheme.textPrimary,
                 fontFamily: FONTS[settings.fontStyle].bold
               }
             ]}>
               Email
             </Text>
             <TextInput
               style={[
                 styles.input,
                 { 
                   backgroundColor: currentTheme.background,
                   borderColor: currentTheme.border,
                   color: currentTheme.textPrimary,
                   fontFamily: FONTS[settings.fontStyle].regular
                 }
               ]}
               placeholder="your.email@example.com"
               placeholderTextColor={currentTheme.textTertiary}
               value={profile.email}
               onChangeText={(text) => setProfile({ ...profile, email: text })}
               keyboardType="email-address"
               autoCapitalize="none"
               editable={isEditing}
             />
           </View>
         </View>
 
         {isEditing && (
           <View style={styles.buttonRow}>
             <TouchableOpacity
               style={[styles.button, styles.cancelButton, { backgroundColor: currentTheme.border }]}
               onPress={() => {
                 setIsEditing(false);
                 loadData();
               }}
               activeOpacity={0.8}
             >
               <Text style={[
                 styles.buttonText, 
                 { 
                   color: currentTheme.textPrimary,
                   fontFamily: FONTS[settings.fontStyle].bold
                 }
               ]}>
                 Cancel
               </Text>
             </TouchableOpacity>
             <TouchableOpacity
               style={[styles.button, styles.saveButton, { backgroundColor: currentTheme.primary }]}
               onPress={handleSaveProfile}
               activeOpacity={0.8}
             >
               <Text style={[
                 styles.buttonText, 
                 { 
                   color: currentTheme.cardBackground,
                   fontFamily: FONTS[settings.fontStyle].bold
                 }
               ]}>
                 Save Changes
               </Text>
             </TouchableOpacity>
           </View>
         )}
       </View>
 
       {/* Theme Section */}
       <View style={[styles.section, { backgroundColor: currentTheme.cardBackground }]}>
         <Text style={[
           styles.sectionTitle, 
           { 
             color: currentTheme.textPrimary,
             fontFamily: FONTS[settings.fontStyle].bold
           }
         ]}>
           Theme
         </Text>
         <Text style={[
           styles.sectionSubtitle, 
           { 
             color: currentTheme.textSecondary,
             fontFamily: FONTS[settings.fontStyle].regular
           }
         ]}>
           Choose your preferred color theme
         </Text>
 
         <View style={styles.optionsGrid}>
           <TouchableOpacity
             style={[
               styles.themeOption,
               settings.theme === 'green' && styles.selectedOption,
               { borderColor: settings.theme === 'green' ? THEMES.green.primary : currentTheme.border }
             ]}
             onPress={() => handleThemeChange('green')}
             activeOpacity={0.7}
           >
             <View style={[styles.themePreview, { backgroundColor: THEMES.green.accent }]}>
               <Text style={styles.themeEmoji}>🌿</Text>
             </View>
             <Text style={[
               styles.optionLabel, 
               { 
                 color: currentTheme.textPrimary,
                 fontFamily: FONTS[settings.fontStyle].bold
               }
             ]}>
               Nature Green
             </Text>
             {settings.theme === 'green' && (
               <View style={[styles.checkBadge, { backgroundColor: THEMES.green.primary }]}>
                 <Text style={styles.checkText}>✓</Text>
               </View>
             )}
           </TouchableOpacity>
 
           <TouchableOpacity
             style={[
               styles.themeOption,
               settings.theme === 'pink' && styles.selectedOption,
               { borderColor: settings.theme === 'pink' ? THEMES.pink.primary : currentTheme.border }
             ]}
             onPress={() => handleThemeChange('pink')}
             activeOpacity={0.7}
           >
             <View style={[styles.themePreview, { backgroundColor: THEMES.pink.accent }]}>
               <Text style={styles.themeEmoji}>🌸</Text>
             </View>
             <Text style={[
               styles.optionLabel, 
               { 
                 color: currentTheme.textPrimary,
                 fontFamily: FONTS[settings.fontStyle].bold
               }
             ]}>
               Blossom Pink
             </Text>
             {settings.theme === 'pink' && (
               <View style={[styles.checkBadge, { backgroundColor: THEMES.pink.primary }]}>
                 <Text style={styles.checkText}>✓</Text>
               </View>
             )}
           </TouchableOpacity>
         </View>
       </View>
 
       {/* Font Section */}
       <View style={[styles.section, { backgroundColor: currentTheme.cardBackground }]}>
         <Text style={[
           styles.sectionTitle, 
           { 
             color: currentTheme.textPrimary,
             fontFamily: FONTS[settings.fontStyle].bold
           }
         ]}>
           Font Style
         </Text>
         <Text style={[
           styles.sectionSubtitle, 
           { 
             color: currentTheme.textSecondary,
             fontFamily: FONTS[settings.fontStyle].regular
           }
         ]}>
           Choose your preferred font style
         </Text>
 
         <View style={styles.fontOptions}>
           {(['default', 'serif', 'mono'] as const).map((font) => (
             <TouchableOpacity
               key={font}
               style={[
                 styles.fontOption,
                 settings.fontStyle === font && [styles.selectedOption, { borderColor: currentTheme.primary }],
                 { backgroundColor: currentTheme.background, borderColor: currentTheme.border }
               ]}
               onPress={() => handleFontChange(font)}
               activeOpacity={0.7}
             >
               <Text
                 style={[
                   styles.fontSample,
                   { 
                     fontFamily: FONTS[font].regular,
                     color: currentTheme.textPrimary,
                   }
                 ]}
               >
                 {FONTS[font].name}
               </Text>
               {settings.fontStyle === font && (
                 <View style={[styles.checkBadge, { backgroundColor: currentTheme.primary }]}>
                   <Text style={styles.checkText}>✓</Text>
                 </View>
               )}
             </TouchableOpacity>
           ))}
         </View>
       </View>
 
       <View style={styles.bottomSpacer} />
     </ScrollView>
   </SafeAreaView>
 );
}

const styles = StyleSheet.create({
 container: {
   flex: 1,
 },
 scrollView: {
   flex: 1,
 },
 scrollContent: {
   padding: 20,
 },
 title: