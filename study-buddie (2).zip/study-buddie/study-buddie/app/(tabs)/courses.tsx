import React, { useState, useEffect } from 'react';
import {
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
  SafeAreaView,
  ScrollView,
  TextInput,
  Alert,
  Modal,
} from 'react-native';
import { useRouter } from 'expo-router';
import * as Haptics from 'expo-haptics';
import { Course } from '@/types/profile';
import { loadCourses, addCourse, deleteCourse } from '@/utils/profileStorage';

const COURSE_COLORS = [
  '#A8C69F', // Soft moss green
  '#C9DCBB', // Pale pistachio
  '#E8DCC4', // Warm cream beige
  '#B8C5A0', // Fresh sage
  '#D4C5A0', // Warm beige
  '#C19A7A', // Soft terracotta
];

export default function CoursesScreen() {
  const router = useRouter();
  const [courses, setCourses] = useState<Course[]>([]);
  const [modalVisible, setModalVisible] = useState(false);
  const [newCourseName, setNewCourseName] = useState('');
  const [selectedColor, setSelectedColor] = useState(COURSE_COLORS[0]);

  useEffect(() => {
    loadCoursesData();
  }, []);

  const loadCoursesData = async () => {
    const data = await loadCourses();
    setCourses(data);
  };

  const handleAddCourse = async () => {
    if (!newCourseName.trim()) {
      Alert.alert('Course Name Required', 'Please enter a course name.');
      return;
    }

    try {
      const newCourse: Course = {
        id: Date.now().toString(),
        name: newCourseName.trim(),
        color: selectedColor,
        createdAt: Date.now(),
      };

      await addCourse(newCourse);
      await loadCoursesData();
      setNewCourseName('');
      setSelectedColor(COURSE_COLORS[0]);
      setModalVisible(false);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    } catch {
      Alert.alert('Error', 'Failed to add course. Please try again.');
    }
  };

  const handleDeleteCourse = (courseId: string, courseName: string) => {
    Alert.alert(
      'Delete Course',
      `Are you sure you want to delete "${courseName}"?`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: async () => {
            try {
              await deleteCourse(courseId);
              await loadCoursesData();
              Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
            } catch {
              Alert.alert('Error', 'Failed to delete course.');
            }
          },
        },
      ]
    );
  };

  const handleCoursePress = (course: Course) => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    router.push({
      pathname: '/mood-selection',
      params: { courseId: course.id, courseName: course.name },
    });
  };

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView style={styles.scrollView} contentContainerStyle={styles.scrollContent}>
        <Text style={styles.title}>My Courses</Text>
        <Text style={styles.subtitle}>Select a course to start studying</Text>

        {courses.length === 0 ? (
          <View style={styles.emptyState}>
            <Text style={styles.emptyEmoji}>📚</Text>
            <Text style={styles.emptyText}>No courses yet</Text>
            <Text style={styles.emptySubtext}>Add your first course to get started!</Text>
          </View>
        ) : (
          <View style={styles.coursesGrid}>
            {courses.map(course => (
              <TouchableOpacity
                key={course.id}
                style={[styles.courseCard, { backgroundColor: course.color }]}
                onPress={() => handleCoursePress(course)}
                onLongPress={() => handleDeleteCourse(course.id, course.name)}
                activeOpacity={0.7}
              >
                <Text style={styles.courseName}>{course.name}</Text>
                <Text style={styles.courseEmoji}>📖</Text>
              </TouchableOpacity>
            ))}
          </View>
        )}

        <TouchableOpacity
          style={styles.addButton}
          onPress={() => setModalVisible(true)}
          activeOpacity={0.8}
        >
          <Text style={styles.addButtonText}>+ Add Course</Text>
        </TouchableOpacity>
      </ScrollView>

      {/* Add Course Modal */}
      <Modal
        visible={modalVisible}
        animationType="slide"
        transparent
        onRequestClose={() => setModalVisible(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Add New Course</Text>

            <TextInput
              style={styles.modalInput}
              placeholder="Course name"
              placeholderTextColor="#9A9B8E"
              value={newCourseName}
              onChangeText={setNewCourseName}
              autoFocus
            />

            <Text style={styles.colorLabel}>Choose a color:</Text>
            <View style={styles.colorGrid}>
              {COURSE_COLORS.map(color => (
                <TouchableOpacity
                  key={color}
                  style={[
                    styles.colorOption,
                    { backgroundColor: color },
                    selectedColor === color && styles.colorSelected,
                  ]}
                  onPress={() => setSelectedColor(color)}
                />
              ))}
            </View>

            <View style={styles.modalButtons}>
              <TouchableOpacity
                style={[styles.modalButton, styles.cancelButton]}
                onPress={() => {
                  setModalVisible(false);
                  setNewCourseName('');
                  setSelectedColor(COURSE_COLORS[0]);
                }}
              >
                <Text style={styles.cancelButtonText}>Cancel</Text>
              </TouchableOpacity>

              <TouchableOpacity
                style={[styles.modalButton, styles.saveButton]}
                onPress={handleAddCourse}
              >
                <Text style={styles.saveButtonText}>Add</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F5F3ED' },
  scrollView: { flex: 1 },
  scrollContent: { padding: 20 },
  title: { fontSize: 32, fontWeight: 'bold', color: '#3D4037', marginBottom: 8 },
  subtitle: { fontSize: 16, color: '#6B7064', marginBottom: 24 },
  emptyState: { backgroundColor: '#FDFBF7', borderRadius: 16, padding: 40, alignItems: 'center', marginBottom: 24 },
  emptyEmoji: { fontSize: 64, marginBottom: 16 },
  emptyText: { fontSize: 20, fontWeight: '600', color: '#3D4037', marginBottom: 8 },
  emptySubtext: { fontSize: 16, color: '#6B7064', textAlign: 'center' },
  coursesGrid: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between', marginBottom: 24 },
  courseCard: { width: '48%', aspectRatio: 1, borderRadius: 16, padding: 20, justifyContent: 'space-between', marginBottom: 16, shadowColor: '#6B7064', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.1, shadowRadius: 4, elevation: 3 },
  courseName: { fontSize: 18, fontWeight: '600', color: '#3D4037' },
  courseEmoji: { fontSize: 32, textAlign: 'right' },
  addButton: { backgroundColor: '#8B9D83', borderRadius: 12, padding: 18, alignItems: 'center' },
  addButtonText: { fontSize: 18, fontWeight: '600', color: '#FDFBF7' },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(61, 64, 55, 0.5)', justifyContent: 'center', alignItems: 'center', padding: 20 },
  modalContent: { backgroundColor: '#FDFBF7', borderRadius: 20, padding: 24, width: '100%', maxWidth: 400 },
  modalTitle: { fontSize: 24, fontWeight: 'bold', color: '#3D4037', marginBottom: 20 },
  modalInput: { backgroundColor: '#F5F3ED', borderRadius: 12, padding: 16, fontSize: 16, color: '#3D4037', marginBottom: 20, borderWidth: 1, borderColor: '#D9D5C8' },
  colorLabel: { fontSize: 16, fontWeight: '600', color: '#3D4037', marginBottom: 12 },
  colorGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 12, marginBottom: 24 },
  colorOption: { width: 50, height: 50, borderRadius: 25, borderWidth: 3, borderColor: 'transparent' },
  colorSelected: { borderColor: '#3D4037' },
  modalButtons: { flexDirection: 'row', gap: 12 },
  modalButton: { flex: 1, borderRadius: 12, padding: 16, alignItems: 'center' },
  cancelButton: { backgroundColor: '#D9D5C8' },
  saveButton: { backgroundColor: '#8B9D83' },
  cancelButtonText: { fontSize: 16, fontWeight: '600', color: '#3D4037' },
  saveButtonText: { fontSize: 16, fontWeight: '600', color: '#FDFBF7' },
});