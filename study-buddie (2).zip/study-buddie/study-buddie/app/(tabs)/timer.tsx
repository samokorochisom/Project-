import React, { useState, useEffect, useRef } from 'react';
import {
 StyleSheet,
 View,
 Text,
 TouchableOpacity,
 SafeAreaView,
 Alert,
 ScrollView,
} from 'react-native';
import { useRouter, useLocalSearchParams } from 'expo-router';
import * as Haptics from 'expo-haptics';
import { activateKeepAwakeAsync, deactivateKeepAwake } from 'expo-keep-awake';
import Svg, { Circle } from 'react-native-svg';
import { MoodType } from '@/types/mood';
import { MOODS } from '@/constants/Moods';
import { addSession } from '@/utils/storage';
import { Session } from '@/types/session';
import { saveActiveSession, clearActiveSession } from '@/utils/activeSessionStorage';
import { useTheme } from '@/contexts/ThemeContext';
import { FONTS } from '@/constants/Themes';
 
export default function StudyScreen() {
 const router = useRouter();
 const { currentTheme, settings } = useTheme();
 const params = useLocalSearchParams();
 const mood = params.mood as MoodType || 'calm';
 const courseId = params.courseId as string;
 const courseName = params.courseName as string;
 
 const moodConfig = MOODS.find(m => m.id === mood) || MOODS[2];
 const STUDY_DURATION = moodConfig.studyDuration * 60;
 
 const [seconds, setSeconds] = useState(STUDY_DURATION);
 const [isRunning, setIsRunning] = useState(false);
 const [sessionTime, setSessionTime] = useState(0);
 const sessionStartTime = useRef<number>(Date.now());
 const hasUnsavedSession = useRef(false);
 
 useEffect(() => {
   // Initialize new session
   sessionStartTime.current = Date.now();
   setSessionTime(0);
   setSeconds(STUDY_DURATION);
   setIsRunning(false);
   hasUnsavedSession.current = false;
 }, [courseId, mood]);
 
 useEffect(() => {
   if (isRunning) {
     activateKeepAwakeAsync();
     saveActiveSession({
       courseId,
       courseName,
       mood,
       startTime: sessionStartTime.current,
       isActive: true,
     });
   } else {
     deactivateKeepAwake();
   }
 
   return () => {
     deactivateKeepAwake();
   };
 }, [isRunning]);
 
 useEffect(() => {
   let interval: NodeJS.Timeout;
 
   if (isRunning && seconds > 0) {
     interval = setInterval(() => {
       setSeconds((prev) => {
         if (prev <= 1) {
           handleTimerComplete();
           return 0;
         }
         return prev - 1;
       });
       setSessionTime((prev) => prev + 1);
       hasUnsavedSession.current = true;
     }, 1000);
   }
 
   return () => {
     if (interval) clearInterval(interval);
   };
 }, [isRunning, seconds]);
 
 useEffect(() => {
   return () => {
     if (hasUnsavedSession.current && sessionTime > 0) {
       const minutesStudied = Math.floor(sessionTime / 60);
       if (minutesStudied > 0) {
         const newSession: Session = {
           id: Date.now().toString(),
           mood: mood,
           duration: minutesStudied,
           timestamp: sessionStartTime.current,
           completed: false,
           courseId: courseId,
           courseName: courseName,
         };
         addSession(newSession).catch(error => {
           console.error('Failed to save session:', error);
         });
       }
     }
   };
 }, [sessionTime]);
 
 const saveSession = async (completed: boolean) => {
   const minutesStudied = Math.floor(sessionTime / 60);
   
   if (minutesStudied === 0) return;
 
   try {
     const newSession: Session = {
       id: Date.now().toString(),
       mood: mood,
       duration: minutesStudied,
       timestamp: sessionStartTime.current,
       completed: completed,
       courseId: courseId,
       courseName: courseName,
     };
 
     await addSession(newSession);
     
     setSessionTime(0);
     sessionStartTime.current = Date.now();
     hasUnsavedSession.current = false;
   } catch (error) {
     console.error('Failed to save session:', error);
   }
 };
 
 const handleTimerComplete = async () => {
   Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
   setIsRunning(false);
   await clearActiveSession();
 
   await saveSession(true);
 
   Alert.alert(
     'Great Work! 🎉',
     'Time for a break!',
     [
       {
         text: 'Take Break',
         onPress: () => {
           router.push({
             pathname: '/break',
             params: {
               courseId,
               courseName,
               mood,
             }
           });
         },
       },
       {
         text: 'Continue Studying',
         onPress: () => {
           setSeconds(STUDY_DURATION);
           setSessionTime(0);
           sessionStartTime.current = Date.now();
           hasUnsavedSession.current = false;
         },
       },
     ]
   );
 };
 
 const handlePlayPause = () => {
   Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
   setIsRunning(!isRunning);
 };
 
 const handleTakeBreak = async () => {
   Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
   
   if (hasUnsavedSession.current && sessionTime > 0) {
     await saveSession(false);
   }
 
   setIsRunning(false);
   await clearActiveSession();
   
   router.push({
     pathname: '/break',
     params: {
       courseId,
       courseName,
       mood,
     }
   });
 };
 
 const handleEndSession = async () => {
   Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
   
   const minutesStudied = Math.floor(sessionTime / 60);
   
   if (minutesStudied === 0) {
     await clearActiveSession();
     router.back();
     return;
   }
 
   Alert.alert(
     'End Session?',
     `You've studied for ${minutesStudied} minute${minutesStudied !== 1 ? 's' : ''}. This will be saved to your progress.`,
     [
       { text: 'Cancel', style: 'cancel' },
       {
         text: 'End Session',
         style: 'destructive',
         onPress: async () => {
           if (hasUnsavedSession.current && sessionTime > 0) {
             await saveSession(false);
           }
           await clearActiveSession();
           router.back();
         },
       },
     ]
   );
 };
 
 const handleReset = () => {
   Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
   Alert.alert(
     'Reset Timer?',
     'This will reset the countdown timer but keep your session time.',
     [
       { text: 'Cancel', style: 'cancel' },
       {
         text: 'Reset',
         onPress: () => {
           setIsRunning(false);
           setSeconds(STUDY_DURATION);
         },
       },
     ]
   );
 };
 
 const formatTime = (totalSeconds: number) => {
   const mins = Math.floor(totalSeconds / 60);
   const secs = totalSeconds % 60;
   return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
 };
 
 const progress = ((STUDY_DURATION - seconds) / STUDY_DURATION) * 100;
 
 const radius = 120;
 const strokeWidth = 12;
 const circumference = 2 * Math.PI * radius;
 const strokeDashoffset = circumference - (progress / 100) * circumference;
 
 return (
   <SafeAreaView style={[styles.container, { backgroundColor: currentTheme.background }]}>
     <ScrollView 
       style={styles.scrollView}
       contentContainerStyle={styles.scrollContent}
       showsVerticalScrollIndicator={false}
     >
       <View style={styles.content}>
         <View style={[styles.card, { backgroundColor: currentTheme.cardBackground }]}>
           <View style={styles.header}>
             <TouchableOpacity 
               style={styles.backButton}
               onPress={handleEndSession}
               activeOpacity={0.7}
             >
               <Text style={[
                 styles.backButtonText, 
                 { 
                   color: currentTheme.primary,
                   fontFamily: FONTS[settings.fontStyle].bold
                 }
               ]}>
                 ← End
               </Text>
             </TouchableOpacity>
             <View style={[styles.courseInfo, { backgroundColor: currentTheme.background }]}>
               <Text style={[
                 styles.courseLabel,
                 { 
                   color: currentTheme.textSecondary,
                   fontFamily: FONTS[settings.fontStyle].regular
                 }
               ]}>
                 Studying
               </Text>
               <Text style={[
                 styles.courseNameText,
                 { 
                   color: currentTheme.textPrimary,
                   fontFamily: FONTS[settings.fontStyle].bold
                 }
               ]}>
                 {courseName}
               </Text>
             </View>
           </View>
 
           <Text style={[
             styles.title,
             { 
               color: currentTheme.textPrimary,
               fontFamily: FONTS[settings.fontStyle].bold
             }
           ]}>
             Study Mode
           </Text>
 
           <View style={[styles.sessionTimeContainer, { backgroundColor: currentTheme.accent }]}>
             <Text style={[
               styles.sessionTimeLabel,
               { 
                 color: currentTheme.textSecondary,
                 fontFamily: FONTS[settings.fontStyle].regular
               }
             ]}>
               Session Time:
             </Text>
             <Text style={[
               styles.sessionTime,
               { 
                 color: currentTheme.textPrimary,
                 fontFamily: FONTS[settings.fontStyle].bold
               }
             ]}>
               {Math.floor(sessionTime / 60)} min
             </Text>
           </View>
 
           <View style={styles.timerContainer}>
             <Svg height="280" width="280">
               <Circle
                 cx="140"
                 cy="140"
                 r={radius}
                 stroke={currentTheme.border}
                 strokeWidth={strokeWidth}
                 fill="none"
               />
               <Circle
                 cx="140"
                 cy="140"
                 r={radius}
                 stroke={currentTheme.primary}
                 strokeWidth={strokeWidth}
                 fill="none"
                 strokeDasharray={circumference}
                 strokeDashoffset={strokeDashoffset}
                 strokeLinecap="round"
                 transform="rotate(-90 140 140)"
               />
             </Svg>
             <View style={styles.timeDisplay}>
               <Text style={[
                 styles.time,
                 { 
                   color: currentTheme.textPrimary,
                   fontFamily: FONTS[settings.fontStyle].bold
                 }
               ]}>
                 {formatTime(seconds)}
               </Text>
             </View>
           </View>
 
           <View style={styles.controls}>
             <TouchableOpacity
               style={[styles.controlButton, { backgroundColor: currentTheme.background }]}
               onPress={handlePlayPause}
               activeOpacity={0.7}
             >
               <Text style={styles.controlIcon}>
                 {isRunning ? '⏸' : '▶️'}
               </Text>
             </TouchableOpacity>
 
             <TouchableOpacity
               style={[styles.controlButton, { backgroundColor: currentTheme.background }]}
               onPress={handleReset}
               activeOpacity={0.7}
             >
               <Text style={styles.controlIcon}>↻</Text>
             </TouchableOpacity>
           </View>
 
           <TouchableOpacity
             style={[styles.breakButton, { backgroundColor: currentTheme.warning }]}
             onPress={handleTakeBreak}
             activeOpacity={0.8}
           >
             <Text style={[
               styles.breakButtonText,
               { 
                 color: currentTheme.cardBackground,
                 fontFamily: FONTS[settings.fontStyle].bold
               }
             ]}>
               ☕ Take a Break
             </Text>
           </TouchableOpacity>
 
           <View style={[styles.info, { borderTopColor: currentTheme.border }]}>
             <View style={styles.infoRow}>
               <Text style={[
                 styles.infoLabel,
                 { 
                   color: currentTheme.textSecondary,
                   fontFamily: FONTS[settings.fontStyle].regular
                 }
               ]}>
                 Target:
               </Text>
               <Text style={[
                 styles.infoValue,
                 { 
                   color: currentTheme.textPrimary,
                   fontFamily: FONTS[settings.fontStyle].bold
                 }
               ]}>
                 {moodConfig.studyDuration} min
               </Text>
             </View>
             <View style={styles.infoRow}>
               <Text style={[
                 styles.infoLabel,
                 { 
                   color: currentTheme.textSecondary,
                   fontFamily: FONTS[settings.fontStyle].regular
                 }
               ]}>
                 Mood:
               </Text>
               <Text style={[
                 styles.infoValue,
                 { 
                   color: currentTheme.textPrimary,
                   fontFamily: FONTS[settings.fontStyle].bold
                 }
               ]}>
                 {moodConfig.emoji} {moodConfig.label}