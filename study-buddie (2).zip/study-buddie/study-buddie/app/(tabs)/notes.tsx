import React, { useState, useEffect } from 'react';
import {
 StyleSheet,
 View,
 Text,
 TouchableOpacity,
 SafeAreaView,
 ScrollView,
} from 'react-native';
import { useRouter } from 'expo-router';
import * as Haptics from 'expo-haptics';
import { Course } from '@/types/profile';
import { loadCourses } from '@/utils/profileStorage';
import { getNotesByCourse, getDocumentsByCourse } from '@/utils/notesStorage';
import { useFocusEffect } from '@react-navigation/native';
import { useCallback } from 'react';
import { useTheme } from '@/contexts/ThemeContext';
import { FONTS } from '@/constants/Themes';
 
interface CourseWithCounts extends Course {
 notesCount: number;
 lessonsCount: number;
 documentsCount: number;
}
 
export default function NotesScreen() {
 const router = useRouter();
 const { currentTheme, settings } = useTheme();
 const [courses, setCourses] = useState<CourseWithCounts[]>([]);
 
 useFocusEffect(
   useCallback(() => {
     loadCoursesData();
   }, [])
 );
 
 useEffect(() => {
   loadCoursesData();
 }, []);
 
 const loadCoursesData = async () => {
   try {
     const coursesData = await loadCourses();
     
     const coursesWithCounts = await Promise.all(
       coursesData.map(async (course) => {
         const notes = await getNotesByCourse(course.id);
         const lessons = await getNotesByCourse(course.id);
         const documents = await getDocumentsByCourse(course.id);
         
         return {
           ...course,
           notesCount: notes.length,
           lessonsCount: lessons.length,
           documentsCount: documents.length,
         };
       })
     );
     
     setCourses(coursesWithCounts);
   } catch (error) {
     console.error('Error loading courses:', error);
   }
 };
 
 const handleCoursePress = (course: CourseWithCounts) => {
   Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
   router.push({
     pathname: '/course-notes',
     params: {
       courseId: course.id,
       courseName: course.name,
       courseColor: course.color,
     }
   });
 };
 
 return (
   <SafeAreaView style={[styles.container, { backgroundColor: currentTheme.background }]}>
     <ScrollView 
       style={styles.scrollView}
       contentContainerStyle={styles.scrollContent}
       showsVerticalScrollIndicator={false}
     >
       <Text style={[
         styles.title, 
         { 
           color: currentTheme.textPrimary,
           fontFamily: FONTS[settings.fontStyle].bold
         }
       ]}>
         Study Notes
       </Text>
       <Text style={[
         styles.subtitle, 
         { 
           color: currentTheme.textSecondary,
           fontFamily: FONTS[settings.fontStyle].regular
         }
       ]}>
         Select a course to view notes, lessons & documents
       </Text>
 
       {courses.length === 0 ? (
         <View style={[styles.emptyState, { backgroundColor: currentTheme.cardBackground }]}>
           <Text style={styles.emptyEmoji}>📝</Text>
           <Text style={[
             styles.emptyText, 
             { 
               color: currentTheme.textPrimary,
               fontFamily: FONTS[settings.fontStyle].bold
             }
           ]}>
             No courses yet
           </Text>
           <Text style={[
             styles.emptySubtext, 
             { 
               color: currentTheme.textSecondary,
               fontFamily: FONTS[settings.fontStyle].regular
             }
           ]}>
             Add courses from the home screen to start taking notes!
           </Text>
         </View>
       ) : (
         <View style={styles.coursesContainer}>
           {courses.map((course) => (
             <TouchableOpacity
               key={course.id}
               style={[
                 styles.courseCard, 
                 { 
                   backgroundColor: currentTheme.cardBackground,
                   borderLeftColor: course.color 
                 }
               ]}
               onPress={() => handleCoursePress(course)}
               activeOpacity={0.7}
             >
               <View style={styles.courseHeader}>
                 <Text style={[
                   styles.courseName, 
                   { 
                     color: currentTheme.textPrimary,
                     fontFamily: FONTS[settings.fontStyle].bold
                   }
                 ]}>
                   {course.name}
                 </Text>
                 <Text style={styles.courseEmoji}>📖</Text>
               </View>
 
               <View style={styles.courseStats}>
                 <View style={styles.statItem}>
                   <Text style={styles.statIcon}>📝</Text>
                   <Text style={[
                     styles.statText, 
                     { 
                       color: currentTheme.textSecondary,
                       fontFamily: FONTS[settings.fontStyle].regular
                     }
                   ]}>
                     {course.notesCount} Notes
                   </Text>
                 </View>
                 <View style={styles.statItem}>
                   <Text style={styles.statIcon}>📚</Text>
                   <Text style={[
                     styles.statText, 
                     { 
                       color: currentTheme.textSecondary,
                       fontFamily: FONTS[settings.fontStyle].regular
                     }
                   ]}>
                     {course.lessonsCount} Lessons
                   </Text>
                 </View>
                 <View style={styles.statItem}>
                   <Text style={styles.statIcon}>📄</Text>
                   <Text style={[
                     styles.statText, 
                     { 
                       color: currentTheme.textSecondary,
                       fontFamily: FONTS[settings.fontStyle].regular
                     }
                   ]}>
                     {course.documentsCount} Files
                   </Text>
                 </View>
               </View>
             </TouchableOpacity>
           ))}
         </View>
       )}
     </ScrollView>
   </SafeAreaView>
 );
}