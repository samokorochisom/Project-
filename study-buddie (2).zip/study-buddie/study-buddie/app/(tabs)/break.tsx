import React, { useState, useEffect } from 'react';
import {
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
  SafeAreaView,
} from 'react-native';
import { useRouter, useLocalSearchParams } from 'expo-router';
import * as Haptics from 'expo-haptics';
import { useTheme } from '@/contexts/ThemeContext';
import { FONTS } from '@/constants/Themes';
import { saveActiveBreak, clearActiveBreak } from '@/utils/activeBreakStorage';

const DEFAULT_BREAK_DURATION = 5 * 60; // 5 minutes in seconds

export default function BreakScreen() {
  const router = useRouter();
  const { currentTheme, settings } = useTheme();
  const params = useLocalSearchParams();
  const courseId = params.courseId as string;
  const courseName = params.courseName as string;
  const mood = params.mood as string;

  const [breakSeconds, setBreakSeconds] = useState(DEFAULT_BREAK_DURATION);
  const [isBreakRunning, setIsBreakRunning] = useState(false);

  useEffect(() => {
    if (isBreakRunning) {
      saveActiveBreak({
        courseId,
        courseName,
        mood,
        startTime: Date.now(),
        isActive: true,
      });
    }
  }, [isBreakRunning]);

  useEffect(() => {
    let interval: NodeJS.Timeout;

    if (isBreakRunning && breakSeconds > 0) {
      interval = setInterval(() => {
        setBreakSeconds((prev) => {
          if (prev <= 1) {
            setIsBreakRunning(false);
            clearActiveBreak();
            Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }

    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isBreakRunning, breakSeconds]);

  const formatTime = (totalSeconds: number) => {
    const mins = Math.floor(totalSeconds / 60);
    const secs = totalSeconds % 60;
    return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
  };

  const handlePlayPause = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    setIsBreakRunning(!isBreakRunning);
  };

  const handleAddTime = (minutes: number) => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    setBreakSeconds(prev => prev + minutes * 60);
  };

  const handleSkipBreak = async () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    await clearActiveBreak();
    router.push({
      pathname: '/study',
      params: { mood, courseId, courseName },
    });
  };

  const handleBackToTimer = async () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    await clearActiveBreak();
    router.push({
      pathname: '/study',
      params: { mood, courseId, courseName },
    });
  };

  const handleReset = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    setBreakSeconds(DEFAULT_BREAK_DURATION);
    setIsBreakRunning(false);
  };

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: currentTheme.background }]}>
      <View style={styles.content}>
        <View style={[styles.card, { backgroundColor: currentTheme.cardBackground }]}>
          {/* Header */}
          <View style={styles.header}>
            <View style={[styles.courseInfo, { backgroundColor: currentTheme.background }]}>
              <Text style={[
                styles.courseLabel,
                { color: currentTheme.textSecondary, fontFamily: FONTS[settings.fontStyle].regular }
              ]}>
                Break from
              </Text>
              <Text style={[
                styles.courseNameText,
                { color: currentTheme.textPrimary, fontFamily: FONTS[settings.fontStyle].bold }
              ]}>
                {courseName}
              </Text>
            </View>
          </View>

          <Text style={[
            styles.title,
            { color: currentTheme.textPrimary, fontFamily: FONTS[settings.fontStyle].bold }
          ]}>
            Break Time!
          </Text>

          {/* Illustration */}
          <View style={styles.illustrationContainer}>
            <View style={[styles.illustration, { backgroundColor: currentTheme.accent }]}>
              <Text style={styles.illustrationEmoji}>☕</Text>
              <Text style={styles.illustrationText}>🧘‍♂️</Text>
            </View>
          </View>

          <Text style={[
            styles.subtitle,
            { color: currentTheme.textSecondary, fontFamily: FONTS[settings.fontStyle].regular }
          ]}>
            Take a quick stretch{'\n'}or drink water.
          </Text>

          {/* Break Timer */}
          <View style={[styles.timerSection, { backgroundColor: currentTheme.background }]}>
            <View style={styles.timerHeader}>
              <Text style={[
                styles.timerLabel,
                { color: currentTheme.textPrimary, fontFamily: FONTS[settings.fontStyle].bold }
              ]}>
                Break Timer
              </Text>
              <TouchableOpacity
                style={[styles.playButton, { backgroundColor: currentTheme.cardBackground }]}
                onPress={handlePlayPause}
                activeOpacity={0.7}
              >
                <Text style={styles.playIcon}>{isBreakRunning ? '⏸' : '▶️'}</Text>
              </TouchableOpacity>
            </View>
            <Text style={[
              styles.timerText,
              { color: currentTheme.textPrimary, fontFamily: FONTS[settings.fontStyle].bold }
            ]}>
              {formatTime(breakSeconds)}
            </Text>
          </View>

          {/* Add Time Buttons */}
          <View style={styles.addTimeContainer}>
            <Text style={[
              styles.addTimeLabel,
              { color: currentTheme.textPrimary, fontFamily: FONTS[settings.fontStyle].bold }
            ]}>
              Add more time:
            </Text>
            <View style={styles.addTimeButtons}>
              <TouchableOpacity
                style={[styles.addTimeButton, { backgroundColor: currentTheme.accentLight }]}
                onPress={() => handleAddTime(1)}
                activeOpacity={0.7}
              >
                <Text style={[
                  styles.addTimeButtonText,
                  { color: currentTheme.textPrimary, fontFamily: FONTS[settings.fontStyle].bold }
                ]}>
                  +1 min
                </Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.addTimeButton, { backgroundColor: currentTheme.accentLight }]}
                onPress={() => handleAddTime(5)}
                activeOpacity={0.7}
              >
                <Text style={[
                  styles.addTimeButtonText,
                  { color: currentTheme.textPrimary, fontFamily: FONTS[settings.fontStyle].bold }
                ]}>
                  +5 min
                </Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.addTimeButton, { backgroundColor: currentTheme.accentLight }]}
                onPress={() => handleAddTime(10)}
                activeOpacity={0.7}
              >
                <Text style={[
                  styles.addTimeButtonText,
                  { color: currentTheme.textPrimary, fontFamily: FONTS[settings.fontStyle].bold }
                ]}>
                  +10 min
                </Text>
              </TouchableOpacity>
            </View>
          </View>

          {/* Action Buttons */}
          <View style={styles.actionButtons}>
            <TouchableOpacity
              style={[styles.actionButton, styles.resetButton, { backgroundColor: currentTheme.border }]}
              onPress={handleReset}
              activeOpacity={0.8}
            >
              <Text style={[
                styles.actionButtonText,
                { color: currentTheme.textPrimary, fontFamily: FONTS[settings.fontStyle].bold }
              ]}>
                Reset
              </Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={[styles.actionButton, styles.skipButton, { backgroundColor: currentTheme.accentDark }]}
              onPress={handleSkipBreak}
              activeOpacity={0.8}
            >
              <Text style={[
                styles.actionButtonText,
                { color: currentTheme.textPrimary, fontFamily: FONTS[settings.fontStyle].bold }
              ]}>
                Skip Break
              </Text>
            </TouchableOpacity>
          </View>

          {/* Back to Timer Button */}
          <TouchableOpacity
            style={[styles.backToTimerButton, { backgroundColor: currentTheme.primary }]}
            onPress={handleBackToTimer}
            activeOpacity={0.8}
          >
            <Text style={[
              styles.backToTimerButtonText,
              { color: currentTheme.cardBackground, fontFamily: FONTS[settings.fontStyle].bold }
            ]}>
              ← Back to Timer
            </Text>
          </TouchableOpacity>
        </View>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: 20 },
  card: { borderRadius: 24, padding: 32, width: '100%', maxWidth: 400, shadowColor: '#6B7064', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.1, shadowRadius: 8, elevation: 4 },
  header: { marginBottom: 16 },
  courseInfo: { borderRadius: 12, padding: 12 },
  courseLabel: { fontSize: 12, marginBottom: 4, textTransform: 'uppercase', letterSpacing: 1 },
  courseNameText: { fontSize: 18, fontWeight: '600' },
  title: { fontSize: 32, fontWeight: 'bold', marginBottom: 24, textAlign: 'center' },
  illustrationContainer: { alignItems: 'center', marginBottom: 24 },
  illustration: { width: 150, height: 150, borderRadius: 75, justifyContent: 'center', alignItems: 'center', position: 'relative' },
  illustrationEmoji: { fontSize: 50, position: 'absolute', bottom: 30, left: 25 },
  illustrationText: { fontSize: 60, marginTop: 10 },
  subtitle: { fontSize: 18, textAlign: 'center', marginBottom: 32, lineHeight: 26 },
  timerSection: { borderRadius: 16, padding: 20, marginBottom: 24 },
  timerHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 },
  timerLabel: { fontSize: 18, fontWeight: '600' },
  playButton: { width: 40, height: 40, borderRadius: 20, justifyContent: 'center', alignItems: 'center', shadowColor: '#6B7064', shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.1, shadowRadius: 2, elevation: 2 },
  playIcon: { fontSize: 18 },
  timerText: { fontSize: 48, fontWeight: 'bold', textAlign: 'center' },
  addTimeContainer: { marginBottom: 24 },
  addTimeLabel: { fontSize: 16, fontWeight: '600', marginBottom: 12, textAlign: 'center' },
  addTimeButtons: { flexDirection: 'row', justifyContent: 'center', gap: 12 },
  addTimeButton: { paddingHorizontal: 20, paddingVertical: 12, borderRadius: 12 },
  addTimeButtonText: { fontSize: 14, fontWeight: '600' },
  actionButtons: { flexDirection: 'row', gap: 12, marginBottom: 16 },
  actionButton: { flex: 1, borderRadius: 12, padding: 16, alignItems: 'center' },
  resetButton: {},
  skipButton: {},
  actionButtonText: { fontSize: 16, fontWeight: '600' },
  backToTimerButton: { borderRadius: 12, padding: 18, alignItems: 'center', shadowColor: '#6B7064', shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.3, shadowRadius: 8, elevation: 4 },
  backToTimerButtonText: { fontSize: 18, fontWeight: '600' },
});