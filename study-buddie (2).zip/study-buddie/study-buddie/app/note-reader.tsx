import React, { useState, useEffect, useCallback } from 'react';
import {
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
  SafeAreaView,
  ScrollView,
  Alert,
} from 'react-native';
import { useRouter, useLocalSearchParams } from 'expo-router';
import * as Haptics from 'expo-haptics';
import { Note, Document as DocType } from '@/types/note';
import { getNoteById, deleteNote, getDocumentsByCourse } from '@/utils/notesStorage';
import { useTheme } from '@/contexts/ThemeContext';
import { FONTS } from '@/constants/Themes';
import { useFocusEffect } from '@react-navigation/native';

export default function NoteReaderScreen() {
  const router = useRouter();
  const { currentTheme, settings } = useTheme();
  const params = useLocalSearchParams();

  const noteId = params.noteId as string;
  const courseId = params.courseId as string;
  const courseName = params.courseName as string;

  const [note, setNote] = useState<Note | null>(null);
  const [documents, setDocuments] = useState<DocType[]>([]);

  useFocusEffect(
    useCallback(() => {
      loadNote();
      loadDocuments();
    }, [])
  );

  const loadNote = async () => {
    try {
      const loadedNote = await getNoteById(noteId);
      if (loadedNote) setNote(loadedNote);
    } catch (error) {
      console.error('Error loading note:', error);
      Alert.alert('Error', 'Failed to load note');
    }
  };

  const loadDocuments = async () => {
    try {
      const docs = await getDocumentsByCourse(courseId);
      setDocuments(docs);
    } catch (error) {
      console.error('Error loading documents:', error);
    }
  };

  const handleEdit = () => {
    if (!note) return;

    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    router.push({
      pathname: '/add-notes',
      params: {
        noteId: note.id,
        courseId: note.courseId,
        courseName: note.courseName,
        title: note.title,
        content: note.content,
        tags: note.tags?.join(',') || '',
        attachments: note.attachments?.join(',') || '',
        createdAt: note.createdAt.toString(),
      },
    });
  };

  const handleDelete = () => {
    if (!note) return;

    Alert.alert(
      'Delete Note',
      `Are you sure you want to delete "${note.title}"?`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: async () => {
            try {
              await deleteNote(noteId);
              Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
              router.back();
            } catch (error) {
              Alert.alert('Error', 'Failed to delete note');
            }
          },
        },
      ]
    );
  };

  const openDocument = (doc: DocType) => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    router.push({
      pathname: '/document-reader',
      params: {
        name: doc.name,
        uri: doc.uri,
        type: doc.type,
      },
    });
  };

  const formatDate = (timestamp: number) => {
    const date = new Date(timestamp);
    const months = [
      'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
      'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
    ];
    return `${months[date.getMonth()]} ${date.getDate()}, ${date.getFullYear()}`;
  };

  const getAttachedDocuments = () => {
    if (!note || !note.attachments) return [];
    return documents.filter(doc => note.attachments?.includes(doc.id));
  };

  if (!note) {
    return (
      <SafeAreaView style={[styles.container, { backgroundColor: currentTheme.background }]}>
        <View style={styles.loadingContainer}>
          <Text style={[styles.loadingText, { color: currentTheme.textSecondary }]}>
            Loading...
          </Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: currentTheme.background }]}>
      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        {/* Header */}
        <View style={styles.header}>
          <TouchableOpacity
            style={styles.backButton}
            onPress={() => router.back()}
            activeOpacity={0.7}
          >
            <Text
              style={[
                styles.backButtonText,
                {
                  color: currentTheme.primary,
                  fontFamily: FONTS[settings.fontStyle].bold
                }
              ]}
            >
              ← Back
            </Text>
          </TouchableOpacity>
          <View style={styles.actionButtons}>
            <TouchableOpacity
              style={[styles.actionButton, { backgroundColor: currentTheme.cardBackground }]}
              onPress={handleEdit}
              activeOpacity={0.7}
            >
              <Text style={styles.actionEmoji}>✏️</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.actionButton, { backgroundColor: currentTheme.cardBackground }]}
              onPress={handleDelete}
              activeOpacity={0.7}
            >
              <Text style={styles.actionEmoji}>🗑️</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Course Info */}
        <View style={[styles.courseInfo, { backgroundColor: currentTheme.cardBackground }]}>
          <Text
            style={[
              styles.courseLabel,
              {
                color: currentTheme.textSecondary,
                fontFamily: FONTS[settings.fontStyle].regular
              }
            ]}
          >
            {courseName}
          </Text>
          <Text
            style={[
              styles.dateText,
              {
                color: currentTheme.textTertiary,
                fontFamily: FONTS[settings.fontStyle].regular
              }
            ]}
          >
            {formatDate(note.updatedAt)}
          </Text>
        </View>

        {/* Title */}
        <Text
          style={[
            styles.title,
            {
              color: currentTheme.textPrimary,
              fontFamily: FONTS[settings.fontStyle].bold
            }
          ]}
        >
          {note.title}
        </Text>

        {/* Tags */}
        {note.tags && note.tags.length > 0 && (
          <View style={styles.tagsContainer}>
            {note.tags.map((tag, index) => (
              <View key={index} style={[styles.tag, { backgroundColor: currentTheme.accent }]}>
                <Text
                  style={[
                    styles.tagText,
                    {
                      color: currentTheme.textSecondary,
                      fontFamily: FONTS[settings.fontStyle].regular
                    }
                  ]}
                >
                  #{tag}
                </Text>
              </View>
            ))}
          </View>
        )}

        {/* Content */}
        <View style={[styles.contentContainer, { backgroundColor: currentTheme.cardBackground }]}>
          <Text
            style={[
              styles.content,
              {
                color: currentTheme.textPrimary,
                fontFamily: FONTS[settings.fontStyle].regular
              }
            ]}
          >
            {note.content}
          </Text>
        </View>

        {/* Attachments Section */}
        {getAttachedDocuments().length > 0 && (
          <View style={styles.attachmentsSection}>
            <Text
              style={[
                styles.sectionTitle,
                {
                  color: currentTheme.textSecondary,
                  fontFamily: FONTS[settings.fontStyle].bold
                }
              ]}
            >
              Attachments ({getAttachedDocuments().length})
            </Text>
            <View style={styles.attachmentsList}>
              {getAttachedDocuments().map((doc) => (
                <TouchableOpacity
                  key={doc.id}
                  style={[styles.attachmentItem, { backgroundColor: currentTheme.cardBackground }]}
                  onPress={() => openDocument(doc)}
                  activeOpacity={0.7}
                >
                  <View style={[styles.attachmentIcon, { backgroundColor: currentTheme.accent }]}>
                    <Text style={styles.documentEmoji}>
                      {doc.type.includes('pdf') ? '📕' :
                        doc.type.includes('image') ? '🖼️' : '📄'}
                    </Text>
                  </View>
                  <View style={styles.attachmentInfo}>
                    <Text
                      style={[
                        styles.attachmentName,
                        {
                          color: currentTheme.textPrimary,
                          fontFamily: FONTS[settings.fontStyle].bold
                        }
                      ]}
                      numberOfLines={1}
                    >
                      {doc.name}
                    </Text>
                    <Text
                      style={[
                        styles.attachmentMeta,
                        {
                          color: currentTheme.textTertiary,
                          fontFamily: FONTS[settings.fontStyle].regular
                        }
                      ]}
                    >
                      {formatFileSize(doc.size)}
                    </Text>
                  </View>
                  <Text style={[styles.openIcon, { color: currentTheme.textSecondary }]}>›</Text>
                </TouchableOpacity>
              ))}
            </View>
          </View>
        )}

        {/* Metadata */}
        <View style={[styles.metadata, { backgroundColor: currentTheme.cardBackground }]}>
          <View style={styles.metadataRow}>
            <Text
              style={[
                styles.metadataLabel,
                {
                  color: currentTheme.textTertiary,
                  fontFamily: FONTS[settings.fontStyle].regular
                }
              ]}
            >
              Created:
            </Text>
            <Text
              style={[
                styles.metadataValue,
                {
                  color: currentTheme.textSecondary,
                  fontFamily: FONTS[settings.fontStyle].regular
                }
              ]}
            >
              {formatDate(note.createdAt)}
            </Text>
          </View>
          <View style={styles.metadataRow}>
            <Text
              style={[
                styles.metadataLabel,
                {
                  color: currentTheme.textTertiary,
                  fontFamily: FONTS[settings.fontStyle].regular
                }
              ]}
            >
              Last Modified:
            </Text>
            <Text
              style={[
                styles.metadataValue,
                {
                  color: currentTheme.textSecondary,
                  fontFamily: FONTS[settings.fontStyle].regular
                }
              ]}
            >
              {formatDate(note.updatedAt)}
            </Text>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

function formatFileSize(bytes: number): string {
  if (bytes < 1024) return bytes + ' B';
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
  return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  loadingText: { fontSize: 16 },
  scrollView: { flex: 1 },
  scrollContent: { padding: 20 },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24 },
  backButton: {},
  backButtonText: { fontSize: 16, fontWeight: '600' },
  actionButtons: { flexDirection: 'row', gap: 8 },
  actionButton: {
    width: 40, height: 40, borderRadius: 20,
    justifyContent: 'center', alignItems: 'center',
    shadowColor: '#6B7064', shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1, shadowRadius: 4, elevation: 2,
  },
  actionEmoji: { fontSize: 18 },
  courseInfo: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', borderRadius: 12, padding: 16, marginBottom: 24 },
  courseLabel: { fontSize: 14, fontWeight: '500' },
  dateText: { fontSize: 12 },
  title: { fontSize: 28, fontWeight: '700', marginBottom: 16, lineHeight: 36 },
  tagsContainer: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 24 },
  tag: { borderRadius: 8, paddingHorizontal: 12, paddingVertical: 6 },
  tagText: { fontSize: 12, fontWeight: '500' },
  contentContainer: { borderRadius: 12, padding: 20, marginBottom: 24, shadowColor: '#6B7064', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.1, shadowRadius: 4, elevation: 2 },
  content: { fontSize: 16, lineHeight: 26 },
  attachmentsSection: { marginBottom: 24 },
  sectionTitle: { fontSize: 14, fontWeight: '700', marginBottom: 12 },
  attachmentsList: { gap: 12 },
  attachmentItem: { flexDirection: 'row', alignItems: 'center', borderRadius: 12, padding: 16, shadowColor: '#6B7064', shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.08, shadowRadius: 4, elevation: 2 },
  attachmentIcon: { width: 48, height: 48, borderRadius: 8, justifyContent: 'center', alignItems: 'center', marginRight: 12 },
  documentEmoji: { fontSize: 24 },
  attachmentInfo: { flex: 1 },
  attachmentName: { fontSize: 16, fontWeight: '600', marginBottom: 4 },
  attachmentMeta: { fontSize: 12 },
  openIcon: { fontSize: 24, marginLeft: 8 },
  metadata: { borderRadius: 12, padding: 16, gap: 12 },
  metadataRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  metadataLabel: { fontSize: 14 },
  metadataValue: { fontSize: 14, fontWeight: '500' },
});