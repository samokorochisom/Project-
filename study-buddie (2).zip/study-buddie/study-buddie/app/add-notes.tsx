import React, { useState, useEffect } from 'react';
import {
  StyleSheet,
  View,
  Text,
  TextInput,
  TouchableOpacity,
  SafeAreaView,
  ScrollView,
  Alert,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';
import { useRouter, useLocalSearchParams } from 'expo-router';
import * as Haptics from 'expo-haptics';
import { saveNote, getDocumentsByCourse } from '@/utils/notesStorage';
import { Note, Document as DocType } from '@/types/note';
import { useTheme } from '@/contexts/ThemeContext';
import { FONTS } from '@/constants/Themes';

export default function AddNotesScreen() {
  const router = useRouter();
  const { currentTheme, settings } = useTheme();
  const params = useLocalSearchParams();

  const courseId = params.courseId as string;
  const courseName = params.courseName as string;
  const editingNoteId = params.noteId as string | undefined;

  const [title, setTitle] = useState(params.title as string || '');
  const [content, setContent] = useState(params.content as string || '');
  const [tags, setTags] = useState(params.tags ? (params.tags as string).split(',') : []);
  const [tagInput, setTagInput] = useState('');
  const [attachments, setAttachments] = useState<string[]>(
    params.attachments ? (params.attachments as string).split(',') : []
  );
  const [availableDocuments, setAvailableDocuments] = useState<DocType[]>([]);
  const [showDocumentPicker, setShowDocumentPicker] = useState(false);

  useEffect(() => {
    loadDocuments();
  }, []);

  const loadDocuments = async () => {
    try {
      const docs = await getDocumentsByCourse(courseId);
      setAvailableDocuments(docs);
    } catch (error) {
      console.error('Error loading documents:', error);
    }
  };

  const handleSave = async () => {
    if (!title.trim()) {
      Alert.alert('Error', 'Please enter a title');
      return;
    }

    if (!content.trim()) {
      Alert.alert('Error', 'Please enter some content');
      return;
    }

    try {
      const note: Note = {
        id: editingNoteId || Date.now().toString(),
        courseId,
        courseName,
        title: title.trim(),
        content: content.trim(),
        tags: tags.filter(t => t.trim()),
        attachments,
        createdAt: editingNoteId ? parseInt(params.createdAt as string) : Date.now(),
        updatedAt: Date.now(),
      };

      await saveNote(note);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      router.back();
    } catch (error) {
      console.error('Error saving note:', error);
      Alert.alert('Error', 'Failed to save note');
    }
  };

  const addTag = () => {
    if (tagInput.trim() && !tags.includes(tagInput.trim())) {
      setTags([...tags, tagInput.trim()]);
      setTagInput('');
    }
  };

  const removeTag = (tagToRemove: string) => {
    setTags(tags.filter(tag => tag !== tagToRemove));
  };

  const toggleAttachment = (docId: string) => {
    if (attachments.includes(docId)) {
      setAttachments(attachments.filter(id => id !== docId));
    } else {
      setAttachments([...attachments, docId]);
    }
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
  };

  const openDocument = (doc: DocType) => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    router.push({
      pathname: '/document-reader',
      params: {
        name: doc.name,
        uri: doc.uri,
        type: doc.type,
      }
    });
  };

  const getAttachedDocuments = () => {
    return availableDocuments.filter(doc => attachments.includes(doc.id));
  };

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: currentTheme.background }]}>
      <KeyboardAvoidingView 
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={styles.keyboardView}
      >
        <ScrollView 
          style={styles.scrollView}
          contentContainerStyle={styles.scrollContent}
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps="handled"
        >
          {/* Header */}
          <View style={styles.header}>
            <TouchableOpacity
              style={styles.backButton}
              onPress={() => router.back()}
              activeOpacity={0.7}
            >
              <Text style={[
                styles.backButtonText, 
                { 
                  color: currentTheme.primary,
                  fontFamily: FONTS[settings.fontStyle].bold
                }
              ]}>
                Cancel
              </Text>
            </TouchableOpacity>
            <Text style={[
              styles.headerTitle, 
              { 
                color: currentTheme.textPrimary,
                fontFamily: FONTS[settings.fontStyle].bold
              }
            ]}>
              {editingNoteId ? 'Edit Note' : 'New Note'}
            </Text>
            <TouchableOpacity
              style={styles.saveButton}
              onPress={handleSave}
              activeOpacity={0.7}
            >
              <Text style={[
                styles.saveButtonText, 
                { 
                  color: currentTheme.primary,
                  fontFamily: FONTS[settings.fontStyle].bold
                }
              ]}>
                Save
              </Text>
            </TouchableOpacity>
          </View>

          {/* Course Info */}
          <View style={[styles.courseInfo, { backgroundColor: currentTheme.cardBackground }]}>
            <Text style={[
              styles.courseLabel, 
              { 
                color: currentTheme.textSecondary,
                fontFamily: FONTS[settings.fontStyle].regular
              }
            ]}>
              Course
            </Text>
            <Text style={[
              styles.courseName, 
              { 
                color: currentTheme.textPrimary,
                fontFamily: FONTS[settings.fontStyle].bold
              }
            ]}>
              {courseName}
            </Text>
          </View>

          {/* Title Input */}
          <View style={styles.section}>
            <Text style={[
              styles.label, 
              { 
                color: currentTheme.textSecondary,
                fontFamily: FONTS[settings.fontStyle].bold
              }
            ]}>
              Title
            </Text>
            <TextInput
              style={[
                styles.titleInput,
                { 
                  backgroundColor: currentTheme.cardBackground,
                  color: currentTheme.textPrimary,
                  fontFamily: FONTS[settings.fontStyle].bold
                }
              ]}
              placeholder="Enter note title..."
              placeholderTextColor={currentTheme.textTertiary}
              value={title}
              onChangeText={setTitle}
              maxLength={100}
            />
          </View>

          {/* Content Input */}
          <View style={styles.section}>
            <Text style={[
              styles.label, 
              { 
                color: currentTheme.textSecondary,
                fontFamily: FONTS[settings.fontStyle].bold
              }
            ]}>
              Content
            </Text>
            <TextInput
              style={[
                styles.contentInput,
                { 
                  backgroundColor: currentTheme.cardBackground,
                  color: currentTheme.textPrimary,
                  fontFamily: FONTS[settings.fontStyle].regular
                }
              ]}
              placeholder="Start writing your notes..."
              placeholderTextColor={currentTheme.textTertiary}
              value={content}
              onChangeText={setContent}
              multiline
              textAlignVertical="top"
            />
          </View>

          {/* Attachments Section */}
          <View style={styles.section}>
            <View style={styles.sectionHeader}>
              <Text style={[
                styles.label, 
                { 
                  color: currentTheme.textSecondary,
                  fontFamily: FONTS[settings.fontStyle].bold
                }
              ]}>
                Attachments ({attachments.length})
              </Text>
              <TouchableOpacity
                onPress={() => setShowDocumentPicker(!showDocumentPicker)}
                activeOpacity={0.7}
              >
                <Text style={[
                  styles.addButton, 
                  { 
                    color: currentTheme.primary,
                    fontFamily: FONTS[settings.fontStyle].bold
                  }
                ]}>
                  {showDocumentPicker ? 'Done' : '+ Add'}
                </Text>
              </TouchableOpacity>
            </View>

            {/* Attached Documents */}
            {getAttachedDocuments().length > 0 && (
              <View style={styles.attachedDocuments}>
                {getAttachedDocuments().map((doc) => (
                  <TouchableOpacity
                    key={doc.id}
                    style={[styles.documentChip, { backgroundColor: currentTheme.cardBackground }]}
                    onPress={() => openDocument(doc)}
                    onLongPress={() => toggleAttachment(doc.id)}
                    activeOpacity={0.7}
                  >
                    <Text style={styles.documentEmoji}>
                      {doc.type.includes('pdf') ? '📕' : 
                        doc.type.includes('image') ? '🖼️' : '📄'}
                    </Text>
                    <Text 
                      style={[
                        styles.documentChipText, 
                        { 
                          color: currentTheme.textPrimary,
                          fontFamily: FONTS[settings.fontStyle].regular
                        }
                      ]}
                      numberOfLines={1}
                    >
                      {doc.name}
                    </Text>
                    <TouchableOpacity
                      onPress={() => toggleAttachment(doc.id)}
                      hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
                    >
                      <Text style={styles.removeIcon}>✕</Text>
                    </TouchableOpacity>
                  </TouchableOpacity>
                ))}
              </View>
            )}

            {/* Document Picker */}
            {showDocumentPicker && (
              <View style={[styles.documentPicker, { backgroundColor: currentTheme.cardBackground }]}>
                {availableDocuments.length === 0 ? (
                  <Text style={[
                    styles.noDocumentsText, 
                    { 
                      color: currentTheme.textSecondary,
                      fontFamily: FONTS[settings.fontStyle].regular
                    }
                  ]}>
                    No documents available. Upload documents in the Files tab.
                  </Text>
                ) : (
                  availableDocuments.map((doc) => (
                    <TouchableOpacity
                      key={doc.id}
                      style={[
                        styles.documentItem,
                        attachments.includes(doc.id) && { 
                          backgroundColor: currentTheme.primary + '20' 
                        }
                      ]}
                      onPress={() => toggleAttachment(doc.id)}
                      activeOpacity={0.7}
                    >
                      <Text style={styles.documentEmoji}>
                        {doc.type.includes('pdf') ? '📕' : 
                          doc.type.includes('image') ? '🖼️' : '📄'}
                      </Text>
                      <Text 
                        style={[
                          styles.documentItemText, 
                          { 
                            color: currentTheme.textPrimary,
                            fontFamily: FONTS[settings.fontStyle].regular
                          }
                        ]}
                        numberOfLines={1}
                      >
                        {doc.name}
                      </Text>
                      {attachments.includes(doc.id) && (
                        <Text style={[styles.checkmark, { color: currentTheme.primary }]}>✓</Text>
                      )}
                    </TouchableOpacity>
                  ))
                )}
              </View>
            )}
          </View>

          {/* Tags Section */}
          <View style={styles.section}>
            <Text style={[
              styles.label, 
              { 
                color: currentTheme.textSecondary,
                fontFamily: FONTS[settings.fontStyle].bold
              }
            ]}>
              Tags
            </Text>
            <View style={styles.tagInputContainer}>
              <TextInput
                style={[
                  styles.tagInput,
                  { 
                    backgroundColor: currentTheme.cardBackground,
                    color: currentTheme.textPrimary,
                    fontFamily: FONTS[settings.fontStyle].regular
                  }
                ]}
                placeholder="Add a tag..."
                placeholderTextColor={currentTheme.textTertiary}
                value={tagInput}
                onChangeText={setTagInput}
                onSubmitEditing={addTag}
                returnKeyType="done"
              />
              <TouchableOpacity
                style={[styles.addTagButton, { backgroundColor: currentTheme.primary }]}
                onPress={addTag}
                activeOpacity={0.7}
              >
                <Text style={[
                  styles.addTagButtonText, 
                  { 
                    color: currentTheme.cardBackground,
                    fontFamily: FONTS[settings.fontStyle].bold
                  }
                ]}>
                  Add
                </Text>
              </TouchableOpacity>
            </View>
            {tags.length > 0 && (
              <View style={styles.tagsContainer}>
                {tags.map((tag, index) => (
                  <View key={index} style={[styles.tag, { backgroundColor: currentTheme.accent }]}>
                    <Text style={[
                      styles.tagText, 
                      { 
                        color: currentTheme.textSecondary,
                        fontFamily: FONTS[settings.fontStyle].regular
                      }
                    ]}>
                      #{tag}
                    </Text>
                    <TouchableOpacity
                      onPress={() => removeTag(tag)}
                      hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
                    >
                      <Text style={[styles.removeTag, { color: currentTheme.textSecondary }]}>✕</Text>
                    </TouchableOpacity>
                  </View>
                ))}
              </View>
            )}
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  keyboardView: {
    flex: 1,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    padding: 20,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 24,
  },
  backButton: {},
  backButtonText: {
    fontSize: 16,
    fontWeight: '600',
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: '700',
  },
  saveButton: {},
  saveButtonText: {
    fontSize: 16,
    fontWeight: '600',
  },
  courseInfo: {
    borderRadius: 12,
    padding: 16,
    marginBottom: 24,
  },
  courseLabel: {
    fontSize: 12,
    marginBottom: 4,
  },
  courseName: {
    fontSize: 18,
    fontWeight: '700',
  },
  section: {
    marginBottom: 24,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  label: {
    fontSize: 14,
    marginBottom: 8,
  },
  addButton: {
    fontSize: 14,
    fontWeight: '600',
  },
  titleInput: {
    borderRadius: 12,
    padding: 16,
    fontSize: 18,
    fontWeight: '700',
  },
  contentInput: {
    borderRadius: 12,
    padding: 16,
    fontSize: 16,
    minHeight: 200,
    lineHeight: 24,
  },
  attachedDocuments: {
    gap: 8,
    marginBottom: 12,
  },
  documentChip: {
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: 8,
    padding: 12,
    gap: 8,
  },
  documentEmoji: {
    fontSize: 20,
  },
  documentChipText: {
    flex: 1,
    fontSize: 14,
  },
  removeIcon: {
    fontSize: 16,
    color: '#999',
  },
  documentPicker: {
    borderRadius: 12,
    padding: 12,
    maxHeight: 300,
  },
  noDocumentsText: {
    fontSize: 14,
    textAlign: 'center',
    padding: 20,
  },
  documentItem: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 12,
    borderRadius: 8,
    marginBottom: 8,
    gap: 8,
  },
  documentItemText: {
    flex: 1,
    fontSize: 14,
  },
  checkmark: {
    fontSize: 20,
    fontWeight: 'bold',
  },
  tagInputContainer: {
    flexDirection: 'row',
    gap: 8,
  },
  tagInput: {
    flex: 1,
    borderRadius: 12,
    padding: 12,
    fontSize: 14,
  },
  addTagButton: {
    borderRadius: 12,
    paddingHorizontal: 20,
    justifyContent: 'center',
    alignItems: 'center',
  },
  addTagButtonText: {
    fontSize: 14,
    fontWeight: '600',
  },
  tagsContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
    marginTop: 12,
  },
  tag: {
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 6,
    gap: 6,
  },
  tagText: {
    fontSize: 12,
    fontWeight: '500',
  },
  removeTag: {
    fontSize: 14,
    fontWeight: 'bold',
  },
});