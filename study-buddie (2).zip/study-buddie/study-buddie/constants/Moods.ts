// constants/Moods.ts

import { Mood } from '@/types/mood';

export const MOODS: Mood[] = [
  {
    id: 'tired',
    emoji: '😔',
    label: 'Tired',
    color: '#E6D7FF',
    studyDuration: 25, // 25 minutes - shorter session when tired
    breakDuration: 5,
  },
  {
    id: 'distracted',
    emoji: '😮',
    label: 'Distracted',
    color: '#D4F1F9',
    studyDuration: 45, // 45 minutes - medium session
    breakDuration: 10,
  },
  {
    id: 'calm',
    emoji: '😊',
    label: 'Calm',
    color: '#D4F4DD',
    studyDuration: 90, // 1 hour 30 minutes - longer focused session
    breakDuration: 15,
  },
  {
    id: 'energetic',
    emoji: '💪',
    label: 'Energetic',
    color: '#FFE8D6',
    studyDuration: 120, // 2 hours - maximum energy session
    breakDuration: 20,
  },
];

export const MOOD_EMOJIS = {
  tired: '😔',
  distracted: '😮',
  calm: '😊',
  energetic: '💪',
} as const;

export const MOOD_LABELS = {
  tired: 'Tired',
  distracted: 'Distracted',
  calm: 'Calm',
  energetic: 'Energetic',
} as const;

export const MOOD_COLORS = {
  tired: '#E6D7FF',
  distracted: '#D4F1F9',
  calm: '#D4F4DD',
  energetic: '#FFE8D6',
} as const;