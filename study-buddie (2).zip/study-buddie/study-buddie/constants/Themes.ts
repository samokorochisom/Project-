// constants/Themes.ts

import { Platform } from 'react-native';

export const THEMES = {
  green: {
    name: 'Nature Green',
    primary: '#8B9D83',
    secondary: '#C5D3A8',
    background: '#F5F3ED',
    cardBackground: '#FDFBF7',
    textPrimary: '#3D4037',
    textSecondary: '#6B7064',
    textTertiary: '#9A9B8E',
    border: '#D9D5C8',
    accent: '#A8C69F',
    accentLight: '#C9DCBB',
    accentDark: '#B8C5A0',
    warning: '#C19A7A',
    tagBackground: '#E8DCC4',
  },
  pink: {
    name: 'Blossom Pink',
    primary: '#D4969C',
    secondary: '#F4C4C7',
    background: '#FFF5F7',
    cardBackground: '#FFFFFF',
    textPrimary: '#5D3A3E',
    textSecondary: '#8B7478',
    textTertiary: '#B5A5A8',
    border: '#F0D9DC',
    accent: '#E8B4B8',
    accentLight: '#F5D6D9',
    accentDark: '#C88E94',
    warning: '#D8A47F',
    tagBackground: '#FDE9EC',
  },
} as const;

export const FONTS = {
  default: {
    name: 'Default',
    regular: Platform.select({
      ios: 'System',
      android: 'Roboto',
      default: 'System',
    }),
    bold: Platform.select({
      ios: 'System',
      android: 'Roboto',
      default: 'System',
    }),
  },
  serif: {
    name: 'Serif',
    regular: Platform.select({
      ios: 'Georgia',
      android: 'serif',
      default: 'serif',
    }),
    bold: Platform.select({
      ios: 'Georgia-Bold',
      android: 'serif',
      default: 'serif',
    }),
  },
  mono: {
    name: 'Monospace',
    regular: Platform.select({
      ios: 'Courier',
      android: 'monospace',
      default: 'monospace',
    }),
    bold: Platform.select({
      ios: 'Courier-Bold',
      android: 'monospace',
      default: 'monospace',
    }),
  },
} as const;