// constants/Storage.ts

export const STORAGE_KEYS = {
  SESSIONS: '@study_sessions',
  SETTINGS: '@study_settings',
  USER_PREFERENCES: '@user_preferences',
  LAST_MOOD: '@last_mood',
  TOTAL_STUDY_TIME: '@total_study_time',
  USER_PROFILE: '@user_profile',
  COURSES: '@courses',
  NOTES: '@notes',
  LESSONS: '@lessons',
  DOCUMENTS: '@documents',
} as const;