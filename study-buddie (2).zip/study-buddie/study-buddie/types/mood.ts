// types/mood.ts

export type MoodType = 'tired' | 'distracted' | 'calm' | 'energetic';

export interface Mood {
  id: MoodType;
  emoji: string;
  label: string;
  color: string;
  studyDuration: number; // in minutes
  breakDuration: number; // in minutes
}