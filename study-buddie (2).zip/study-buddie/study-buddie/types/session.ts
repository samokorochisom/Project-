// types/session.ts

import { MoodType } from './mood';

export interface Session {
  id: string;
  mood: MoodType;
  duration: number; // in minutes
  timestamp: number;
  completed: boolean;
  courseId?: string; // Added for course tracking
  courseName?: string;
}

export interface SessionStats {
  totalMinutes: number;
  totalSessions: number;
  mostCommonMood: MoodType;
  sessionsToday: number;
  averageSessionLength: number;
}