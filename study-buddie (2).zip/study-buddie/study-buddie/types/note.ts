// types/note.ts

export interface Note {
  id: string;
  courseId: string;
  courseName: string;
  title: string;
  content: string;
  tags?: string[];
  attachments?: string[]; // Array of document IDs
  createdAt: number;
  updatedAt: number;
}

export interface Document {
  id: string;
  courseId: string;
  courseName: string;
  name: string;
  uri: string;
  type: string;
  size: number;
  uploadedAt: number;
}