// types/profile.ts

export interface UserProfile {
  name: string;
  school?: string;
  age?: string;
  email?: string;
  createdAt: number;
}

export interface Course {
  id: string;
  name: string;
  color: string;
  createdAt: number;
}

export interface AppSettings {
  theme: 'green' | 'pink';
  fontStyle: 'default' | 'serif' | 'mono';
}