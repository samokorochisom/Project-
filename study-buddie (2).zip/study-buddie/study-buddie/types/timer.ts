// types/timer.ts

export interface TimerConfig {
  studyDuration: number;
  breakDuration: number;
  sound: SoundType;
  autoStartBreak: boolean;
  notifications: boolean;
}

export type SoundType = 'cafe' | 'rain' | 'white-noise' | 'silence';

export interface TimerState {
  seconds: number;
  isRunning: boolean;
  isPaused: boolean;
  isBreak: boolean;
  currentSession: string | null;
}