// utils/profileStorage.ts

import AsyncStorage from '@react-native-async-storage/async-storage';
import { UserProfile, Course } from '@/types/profile';
import { STORAGE_KEYS } from '@/constants/Storage';

// Profile functions

export const saveProfile = async (profile: UserProfile): Promise<void> => {
  try {
    await AsyncStorage.setItem(STORAGE_KEYS.USER_PROFILE, JSON.stringify(profile));
  } catch (error) {
    console.error('Error saving profile:', error);
    throw new Error('Failed to save profile');
  }
};

export const loadProfile = async (): Promise<UserProfile | null> => {
  try {
    const data = await AsyncStorage.getItem(STORAGE_KEYS.USER_PROFILE);
    if (data) {
      return JSON.parse(data);
    }
    return null;
  } catch (error) {
    console.error('Error loading profile:', error);
    return null;
  }
};

export const hasProfile = async (): Promise<boolean> => {
  const profile = await loadProfile();
  return profile !== null && profile.name !== '';
};

export const updateProfile = async (updates: Partial<UserProfile>): Promise<void> => {
  try {
    const currentProfile = await loadProfile();
    if (currentProfile) {
      // Update existing profile
      const updatedProfile = { ...currentProfile, ...updates };
      await saveProfile(updatedProfile);
    } else {
      // Create new profile if it doesn't exist
      const newProfile: UserProfile = {
        name: updates.name || '',
        school: updates.school,
        age: updates.age,
        email: updates.email,
        createdAt: updates.createdAt || Date.now(),
      };
      await saveProfile(newProfile);
    }
  } catch (error) {
    console.error('Error updating profile:', error);
    throw new Error('Failed to update profile');
  }
};

// Course functions

export const saveCourses = async (courses: Course[]): Promise<void> => {
  try {
    await AsyncStorage.setItem(STORAGE_KEYS.COURSES, JSON.stringify(courses));
  } catch (error) {
    console.error('Error saving courses:', error);
    throw new Error('Failed to save courses');
  }
};

export const loadCourses = async (): Promise<Course[]> => {
  try {
    const data = await AsyncStorage.getItem(STORAGE_KEYS.COURSES);
    if (data) {
      return JSON.parse(data);
    }
    return [];
  } catch (error) {
    console.error('Error loading courses:', error);
    return [];
  }
};

export const addCourse = async (course: Course): Promise<void> => {
  try {
    const courses = await loadCourses();
    courses.push(course);
    await saveCourses(courses);
  } catch (error) {
    console.error('Error adding course:', error);
    throw new Error('Failed to add course');
  }
};

export const deleteCourse = async (courseId: string): Promise<void> => {
  try {
    const courses = await loadCourses();
    const filtered = courses.filter(c => c.id !== courseId);
    await saveCourses(filtered);
  } catch (error) {
    console.error('Error deleting course:', error);
    throw new Error('Failed to delete course');
  }
};

export const updateCourse = async (courseId: string, updates: Partial<Course>): Promise<void> => {
  try {
    const courses = await loadCourses();
    const index = courses.findIndex(c => c.id === courseId);
    if (index !== -1) {
      courses[index] = { ...courses[index], ...updates };
      await saveCourses(courses);
    }
  } catch (error) {
    console.error('Error updating course:', error);
    throw new Error('Failed to update course');
  }
};