// utils/activeBreakStorage.ts

import AsyncStorage from '@react-native-async-storage/async-storage';

const ACTIVE_BREAK_KEY = '@active_break';

export interface ActiveBreak {
  courseId: string;
  courseName: string;
  mood: string;
  startTime: number;
  isActive: boolean;
}

export const saveActiveBreak = async (breakSession: ActiveBreak): Promise<void> => {
  try {
    await AsyncStorage.setItem(ACTIVE_BREAK_KEY, JSON.stringify(breakSession));
  } catch (error) {
    console.error('Error saving active break:', error);
  }
};

export const loadActiveBreak = async (): Promise<ActiveBreak | null> => {
  try {
    const data = await AsyncStorage.getItem(ACTIVE_BREAK_KEY);
    return data ? JSON.parse(data) : null;
  } catch (error) {
    console.error('Error loading active break:', error);
    return null;
  }
};

export const clearActiveBreak = async (): Promise<void> => {
  try {
    await AsyncStorage.removeItem(ACTIVE_BREAK_KEY);
  } catch (error) {
    console.error('Error clearing active break:', error);
  }
};