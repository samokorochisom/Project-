// utils/notesStorage.ts

import AsyncStorage from '@react-native-async-storage/async-storage';
import { Note, Document as DocType } from '@/types/note';

const NOTES_KEY = '@notes';
const DOCUMENTS_KEY = '@documents';

export const saveNote = async (note: Note): Promise<void> => {
  try {
    const notesJson = await AsyncStorage.getItem(NOTES_KEY);
    const notes: Note[] = notesJson ? JSON.parse(notesJson) : [];
    const existingIndex = notes.findIndex(n => n.id === note.id);

    if (existingIndex >= 0) {
      notes[existingIndex] = note;
    } else {
      notes.push(note);
    }

    await AsyncStorage.setItem(NOTES_KEY, JSON.stringify(notes));
  } catch (error) {
    console.error('Error saving note:', error);
    throw error;
  }
};

export const getNoteById = async (noteId: string): Promise<Note | null> => {
  try {
    const notesJson = await AsyncStorage.getItem(NOTES_KEY);
    const notes: Note[] = notesJson ? JSON.parse(notesJson) : [];
    const note = notes.find(n => n.id === noteId);
    return note || null;
  } catch (error) {
    console.error('Error getting note by id:', error);
    throw error;
  }
};

export const getNotesByCourse = async (courseId: string): Promise<Note[]> => {
  try {
    const notesJson = await AsyncStorage.getItem(NOTES_KEY);
    const notes: Note[] = notesJson ? JSON.parse(notesJson) : [];
    return notes.filter(note => note.courseId === courseId)
      .sort((a, b) => b.updatedAt - a.updatedAt);
  } catch (error) {
    console.error('Error getting notes by course:', error);
    throw error;
  }
};

export const getAllNotes = async (): Promise<Note[]> => {
  try {
    const notesJson = await AsyncStorage.getItem(NOTES_KEY);
    const notes: Note[] = notesJson ? JSON.parse(notesJson) : [];
    return notes.sort((a, b) => b.updatedAt - a.updatedAt);
  } catch (error) {
    console.error('Error getting all notes:', error);
    throw error;
  }
};

export const deleteNote = async (noteId: string): Promise<void> => {
  try {
    const notesJson = await AsyncStorage.getItem(NOTES_KEY);
    const notes: Note[] = notesJson ? JSON.parse(notesJson) : [];
    const filteredNotes = notes.filter(note => note.id !== noteId);
    await AsyncStorage.setItem(NOTES_KEY, JSON.stringify(filteredNotes));
  } catch (error) {
    console.error('Error deleting note:', error);
    throw error;
  }
};

export const searchNotes = async (query: string): Promise<Note[]> => {
  try {
    const notesJson = await AsyncStorage.getItem(NOTES_KEY);
    const notes: Note[] = notesJson ? JSON.parse(notesJson) : [];
    const lowerQuery = query.toLowerCase();

    return notes.filter(note =>
      note.title.toLowerCase().includes(lowerQuery) ||
      note.content.toLowerCase().includes(lowerQuery) ||
      note.tags?.some(tag => tag.toLowerCase().includes(lowerQuery))
    ).sort((a, b) => b.updatedAt - a.updatedAt);
  } catch (error) {
    console.error('Error searching notes:', error);
    throw error;
  }
};

export const addDocument = async (document: DocType): Promise<void> => {
  try {
    const documentsJson = await AsyncStorage.getItem(DOCUMENTS_KEY);
    const documents: DocType[] = documentsJson ? JSON.parse(documentsJson) : [];
    documents.push(document);
    await AsyncStorage.setItem(DOCUMENTS_KEY, JSON.stringify(documents));
  } catch (error) {
    console.error('Error adding document:', error);
    throw error;
  }
};

export const getDocumentById = async (documentId: string): Promise<DocType | null> => {
  try {
    const documentsJson = await AsyncStorage.getItem(DOCUMENTS_KEY);
    const documents: DocType[] = documentsJson ? JSON.parse(documentsJson) : [];
    const document = documents.find(d => d.id === documentId);
    return document || null;
  } catch (error) {
    console.error('Error getting document by id:', error);
    throw error;
  }
};

export const getDocumentsByCourse = async (courseId: string): Promise<DocType[]> => {
  try {
    const documentsJson = await AsyncStorage.getItem(DOCUMENTS_KEY);
    const documents: DocType[] = documentsJson ? JSON.parse(documentsJson) : [];
    return documents.filter(doc => doc.courseId === courseId)
      .sort((a, b) => b.uploadedAt - a.uploadedAt);
  } catch (error) {
    console.error('Error getting documents by course:', error);
    throw error;
  }
};

export const getAllDocuments = async (): Promise<DocType[]> => {
  try {
    const documentsJson = await AsyncStorage.getItem(DOCUMENTS_KEY);
    const documents: DocType[] = documentsJson ? JSON.parse(documentsJson) : [];
    return documents.sort((a, b) => b.uploadedAt - a.uploadedAt);
  } catch (error) {
    console.error('Error getting all documents:', error);
    throw error;
  }
};

export const deleteDocument = async (documentId: string): Promise<void> => {
  try {
    const documentsJson = await AsyncStorage.getItem(DOCUMENTS_KEY);
    const documents: DocType[] = documentsJson ? JSON.parse(documentsJson) : [];
    const filteredDocuments = documents.filter(doc => doc.id !== documentId);
    await AsyncStorage.setItem(DOCUMENTS_KEY, JSON.stringify(filteredDocuments));
  } catch (error) {
    console.error('Error deleting document:', error);
    throw error;
  }
};

export const searchDocuments = async (query: string): Promise<DocType[]> => {
  try {
    const documentsJson = await AsyncStorage.getItem(DOCUMENTS_KEY);
    const documents: DocType[] = documentsJson ? JSON.parse(documentsJson) : [];
    const lowerQuery = query.toLowerCase();

    return documents.filter(doc =>
      doc.name.toLowerCase().includes(lowerQuery) ||
      doc.courseName.toLowerCase().includes(lowerQuery)
    ).sort((a, b) => b.uploadedAt - a.uploadedAt);
  } catch (error) {
    console.error('Error searching documents:', error);
    throw error;
  }
};

export const clearAllData = async (): Promise<void> => {
  try {
    await AsyncStorage.multiRemove([NOTES_KEY, DOCUMENTS_KEY]);
  } catch (error) {
    console.error('Error clearing all data:', error);
    throw error;
  }
};

export const exportData = async (): Promise<{ notes: Note[], documents: DocType[] }> => {
  try {
    const notesJson = await AsyncStorage.getItem(NOTES_KEY);
    const documentsJson = await AsyncStorage.getItem(DOCUMENTS_KEY);
    const notes: Note[] = notesJson ? JSON.parse(notesJson) : [];
    const documents: DocType[] = documentsJson ? JSON.parse(documentsJson) : [];
    return { notes, documents };
  } catch (error) {
    console.error('Error exporting data:', error);
    throw error;
  }
};

export const importData = async (data: { notes: Note[], documents: DocType[] }): Promise<void> => {
  try {
    await AsyncStorage.setItem(NOTES_KEY, JSON.stringify(data.notes));
    await AsyncStorage.setItem(DOCUMENTS_KEY, JSON.stringify(data.documents));
  } catch (error) {
    console.error('Error importing data:', error);
    throw error;
  }
};