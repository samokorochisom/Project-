// utils/settingsStorage.ts

import AsyncStorage from '@react-native-async-storage/async-storage';
import { AppSettings } from '@/types/profile';
import { STORAGE_KEYS } from '@/constants/Storage';

const DEFAULT_SETTINGS: AppSettings = {
  theme: 'green',
  fontStyle: 'default',
};

export const saveSettings = async (settings: AppSettings): Promise<void> => {
  try {
    await AsyncStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(settings));
  } catch (error) {
    console.error('Error saving settings:', error);
    throw new Error('Failed to save settings');
  }
};

export const loadSettings = async (): Promise<AppSettings> => {
  try {
    const data = await AsyncStorage.getItem(STORAGE_KEYS.SETTINGS);
    if (data) {
      return JSON.parse(data);
    }
    return DEFAULT_SETTINGS;
  } catch (error) {
    console.error('Error loading settings:', error);
    return DEFAULT_SETTINGS;
  }
};

export const updateSettings = async (updates: Partial<AppSettings>): Promise<void> => {
  try {
    const currentSettings = await loadSettings();
    const newSettings = { ...currentSettings, ...updates };
    await saveSettings(newSettings);
  } catch (error) {
    console.error('Error updating settings:', error);
    throw new Error('Failed to update settings');
  }
};