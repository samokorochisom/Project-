// utils/storage.ts

import AsyncStorage from '@react-native-async-storage/async-storage';
import { Session } from '@/types/session';
import { STORAGE_KEYS } from '@/constants/Storage';

export const addSession = async (session: Session): Promise<void> => {
  try {
    const sessionsJson = await AsyncStorage.getItem(STORAGE_KEYS.SESSIONS);
    const sessions: Session[] = sessionsJson ? JSON.parse(sessionsJson) : [];
    sessions.push(session);
    await AsyncStorage.setItem(STORAGE_KEYS.SESSIONS, JSON.stringify(sessions));
  } catch (error) {
    console.error('Error adding session:', error);
    throw error;
  }
};

export const getSessions = async (): Promise<Session[]> => {
  try {
    const sessionsJson = await AsyncStorage.getItem(STORAGE_KEYS.SESSIONS);
    return sessionsJson ? JSON.parse(sessionsJson) : [];
  } catch (error) {
    console.error('Error getting sessions:', error);
    return [];
  }
};

export const getSessionsByCourse = async (courseId: string): Promise<Session[]> => {
  try {
    const sessions = await getSessions();
    return sessions.filter(session => session.courseId === courseId);
  } catch (error) {
    console.error('Error getting sessions by course:', error);
    return [];
  }
};

export const clearSessions = async (): Promise<void> => {
  try {
    await AsyncStorage.removeItem(STORAGE_KEYS.SESSIONS);
  } catch (error) {
    console.error('Error clearing sessions:', error);
    throw error;
  }
};