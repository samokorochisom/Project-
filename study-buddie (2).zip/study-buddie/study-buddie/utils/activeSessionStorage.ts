// utils/activeSessionStorage.ts

import AsyncStorage from '@react-native-async-storage/async-storage';

const ACTIVE_SESSION_KEY = '@active_session';

export interface ActiveSession {
  courseId: string;
  courseName: string;
  mood: string;
  startTime: number;
  isActive: boolean;
}

export const saveActiveSession = async (session: ActiveSession): Promise<void> => {
  try {
    await AsyncStorage.setItem(ACTIVE_SESSION_KEY, JSON.stringify(session));
  } catch (error) {
    console.error('Error saving active session:', error);
  }
};

export const loadActiveSession = async (): Promise<ActiveSession | null> => {
  try {
    const data = await AsyncStorage.getItem(ACTIVE_SESSION_KEY);
    return data ? JSON.parse(data) : null;
  } catch (error) {
    console.error('Error loading active session:', error);
    return null;
  }
};

export const clearActiveSession = async (): Promise<void> => {
  try {
    await AsyncStorage.removeItem(ACTIVE_SESSION_KEY);
  } catch (error) {
    console.error('Error clearing active session:', error);
  }
};