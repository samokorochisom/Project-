import React from 'react';
import { StyleSheet, Text, View } from 'react-native';

interface StatCardProps {
  icon: string;
  value: string | number;
  label: string;
}

const StatCard: React.FC<StatCardProps> = ({ icon, value, label }) => {
  return (
    <View style={styles.card}>
      <View style={styles.iconContainer}>
        <Text style={styles.icon}>{icon}</Text>
      </View>
      <Text style={styles.value}>{value}</Text>
      <Text style={styles.label}>{label}</Text>
    </View>
  );
};

interface ProgressStatsProps {
  totalMinutes: number;
  totalSessions: number;
  mostCommonMood: string;
  moodEmoji: string;
}

export const ProgressStats: React.FC<ProgressStatsProps> = ({
  totalMinutes,
  totalSessions,
  mostCommonMood,
  moodEmoji,
}) => {
  return (
    <View style={styles.container}>
      <StatCard icon="⏱️" value={totalMinutes} label="Minutes" />
      <StatCard icon="🔄" value={totalSessions} label="Sessions" />
      <StatCard icon={moodEmoji} value={mostCommonMood} label="Mood" />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    gap: 12,
    marginBottom: 32,
  },
  card: {
    flex: 1,
    backgroundColor: '#FDFBF7', // Off-white with warm undertone
    borderRadius: 16,
    padding: 20,
    alignItems: 'center',
    shadowColor: '#6B7064',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  iconContainer: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: '#C9DCBB', // Pale pistachio
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 12,
  },
  icon: {
    fontSize: 24,
  },
  value: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#3D4037', // Deep forest green-brown
    marginBottom: 4,
  },
  label: {
    fontSize: 14,
    color: '#6B7064', // Muted olive
  },
});