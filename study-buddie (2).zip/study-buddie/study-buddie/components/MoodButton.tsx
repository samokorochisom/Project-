import React from 'react';
import { TouchableOpacity, Text, StyleSheet, ViewStyle } from 'react-native';
import { Mood } from '@/types/mood';

interface MoodButtonProps {
  mood: Mood;
  onPress: () => void;
  isSelected?: boolean;
  style?: ViewStyle;
}

export const MoodButton: React.FC<MoodButtonProps> = ({ 
  mood, 
  onPress, 
  isSelected = false,
  style 
}) => {
  return (
    <TouchableOpacity
      style={[
        styles.container,
        { backgroundColor: mood.color },
        isSelected && styles.selected,
        style,
      ]}
      onPress={onPress}
      activeOpacity={0.7}
    >
      <Text style={styles.emoji}>{mood.emoji}</Text>
      <Text style={styles.label}>{mood.label}</Text>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  container: {
    width: '47%',
    aspectRatio: 1,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  selected: {
    transform: [{ scale: 0.95 }],
    opacity: 0.8,
  },
  emoji: {
    fontSize: 56,
    marginBottom: 8,
  },
  label: {
    fontSize: 18,
    fontWeight: '600',
    color: '#333',
  },
});