import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import Svg, { Circle } from 'react-native-svg';

interface TimerDisplayProps {
  seconds: number;
  totalSeconds: number;
  size?: number;
  strokeWidth?: number;
  color?: string;
}

export const TimerDisplay: React.FC<TimerDisplayProps> = ({
  seconds,
  totalSeconds,
  size = 280,
  strokeWidth = 12,
  color = '#FFB347',
}) => {
  const minutes = Math.floor(seconds / 60);
  const secs = seconds % 60;
  const progress = ((totalSeconds - seconds) / totalSeconds) * 100;

  const radius = (size / 2) - strokeWidth - 10;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (progress / 100) * circumference;
  const center = size / 2;

  return (
    <View style={styles.container}>
      <Svg height={size} width={size}>
        {/* Background circle */}
        <Circle
          cx={center}
          cy={center}
          r={radius}
          stroke="#F0F0F0"
          strokeWidth={strokeWidth}
          fill="none"
        />
        {/* Progress circle */}
        <Circle
          cx={center}
          cy={center}
          r={radius}
          stroke={color}
          strokeWidth={strokeWidth}
          fill="none"
          strokeDasharray={circumference}
          strokeDashoffset={strokeDashoffset}
          strokeLinecap="round"
          transform={`rotate(-90 ${center} ${center})`}
        />
      </Svg>
      <View style={styles.timeContainer}>
        <Text style={styles.time}>
          {String(minutes).padStart(2, '0')}:{String(secs).padStart(2, '0')}
        </Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  timeContainer: {
    position: 'absolute',
  },
  time: {
    fontSize: 64,
    fontWeight: 'bold',
    color: '#3D4037', // Deep forest green-brown
  },
});