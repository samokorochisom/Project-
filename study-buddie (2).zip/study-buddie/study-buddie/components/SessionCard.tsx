import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { Session } from '@/types/session';
import { MoodType } from '@/types/mood';

interface SessionCardProps {
  session: Session;
}

const MOOD_EMOJIS: Record<MoodType, string> = {
  tired: '😔',
  distracted: '😮',
  calm: '😊',
  energetic: '💪',
};

const MOOD_LABELS: Record<MoodType, string> = {
  tired: 'Tired',
  distracted: 'Distracted',
  calm: 'Calm',
  energetic: 'Energetic',
};

export const SessionCard: React.FC<SessionCardProps> = ({ session }) => {
  const formatTime = (timestamp: number) => {
    const date = new Date(timestamp);
    const hours = date.getHours();
    const minutes = date.getMinutes();
    const ampm = hours >= 12 ? 'PM' : 'AM';
    const formattedHours = hours % 12 || 12;
    return `${formattedHours}:${String(minutes).padStart(2, '0')} ${ampm}`;
  };

  return (
    <View style={styles.container}>
      <View style={styles.iconContainer}>
        <Text style={styles.emoji}>{MOOD_EMOJIS[session.mood]}</Text>
      </View>

      <View style={styles.details}>
        <Text style={styles.mood}>{MOOD_LABELS[session.mood]}</Text>
        <Text style={styles.duration}>{session.duration} min</Text>
      </View>

      <View style={styles.timeInfo}>
        <Text style={styles.durationText}>{session.duration} min</Text>
        <Text style={styles.timestamp}>{formatTime(session.timestamp)}</Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FDFBF7', // Off-white with warm undertone
    borderRadius: 16,
    padding: 16,
    marginBottom: 12,
    shadowColor: '#6B7064',
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowOpacity: 0.08,
    shadowRadius: 4,
    elevation: 2,
  },
  iconContainer: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: '#E8DCC4', // Warm cream beige
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
  },
  emoji: {
    fontSize: 28,
  },
  details: {
    flex: 1,
  },
  mood: {
    fontSize: 18,
    fontWeight: '600',
    color: '#3D4037', // Deep forest green-brown
    marginBottom: 4,
  },
  duration: {
    fontSize: 14,
    color: '#6B7064', // Muted olive
  },
  timeInfo: {
    alignItems: 'flex-end',
  },
  durationText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#3D4037', // Deep forest green-brown
    marginBottom: 4,
  },
  timestamp: {
    fontSize: 14,
    color: '#6B7064', // Muted olive
  },
});