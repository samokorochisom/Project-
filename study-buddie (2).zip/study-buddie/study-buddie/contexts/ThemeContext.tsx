// contexts/ThemeContext.tsx

import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { loadSettings, updateSettings } from '@/utils/settingsStorage';
import { AppSettings } from '@/types/profile';
import { THEMES, FONTS } from '@/constants/Themes';

type ThemeContextType = {
  settings: AppSettings;
  currentTheme: typeof THEMES.green;
  updateTheme: (theme: 'green' | 'pink') => Promise<void>;
  updateFont: (fontStyle: 'default' | 'serif' | 'mono') => Promise<void>;
};

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

export function ThemeProvider({ children }: { children: ReactNode }) {
  const [settings, setSettings] = useState<AppSettings>({
    theme: 'green',
    fontStyle: 'default',
  });

  useEffect(() => {
    loadTheme();
  }, []);

  const loadTheme = async () => {
    try {
      const settingsData = await loadSettings();
      setSettings(settingsData);
    } catch (error) {
      console.error('Error loading theme:', error);
    }
  };

  const updateTheme = async (theme: 'green' | 'pink') => {
    try {
      const newSettings = { ...settings, theme };
      setSettings(newSettings);
      await updateSettings(newSettings);
    } catch (error) {
      console.error('Error updating theme:', error);
      throw error;
    }
  };

  const updateFont = async (fontStyle: 'default' | 'serif' | 'mono') => {
    try {
      const newSettings = { ...settings, fontStyle };
      setSettings(newSettings);
      await updateSettings(newSettings);
    } catch (error) {
      console.error('Error updating font:', error);
      throw error;
    }
  };

  const currentTheme = THEMES[settings.theme];

  return (
    <ThemeContext.Provider value={{ settings, currentTheme, updateTheme, updateFont }}>
      {children}
    </ThemeContext.Provider>
  );
}

export function useTheme() {
  const context = useContext(ThemeContext);
  if (context === undefined) {
    throw new Error('useTheme must be used within a ThemeProvider');
  }
  return context;
}